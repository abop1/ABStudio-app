package com.mydownloader.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.setValue

/**
 * 🔥 Smart Filters: creators ki sirf kaam ki videos.
 * 0 = band. Sab band ho to app bilkul pehle jaisi.
 */
object SmartFilter {
    var minViews by mutableLongStateOf(0L)   // jaise 100_000
    var maxDur by mutableIntStateOf(0)       // second, jaise 90
    var maxAgeDays by mutableIntStateOf(0)   // jaise 30

    private fun p(ctx: Context) = ctx.getSharedPreferences("smart_filter", Context.MODE_PRIVATE)

    fun load(ctx: Context) {
        val s = p(ctx)
        minViews = s.getLong("views", 0L); maxDur = s.getInt("dur", 0); maxAgeDays = s.getInt("age", 0)
    }

    fun save(ctx: Context) {
        p(ctx).edit().putLong("views", minViews).putInt("dur", maxDur).putInt("age", maxAgeDays).apply()
    }

    fun active() = minViews > 0 || maxDur > 0 || maxAgeDays > 0

    /** List mein se pehle hi chhaant (jo maloom nahi, usay download ke waqt jaancha jata hai) */
    fun pass(e: CreatorIndex.Entry): Boolean {
        if (minViews > 0 && e.views >= 0 && e.views < minViews) return false
        if (maxDur > 0 && e.dur > 0 && e.dur > maxDur) return false
        if (maxAgeDays > 0 && e.ts > 0) {
            val limit = System.currentTimeMillis() / 1000 - maxAgeDays * 86400L
            if (e.ts < limit) return false
        }
        return true
    }

    /** yt-dlp --match-filter ("?" = agar maloom na ho to guzarne do) */
    fun matchFilter(): String? {
        val parts = mutableListOf<String>()
        if (minViews > 0) parts += "view_count>=?$minViews"
        if (maxDur > 0) parts += "duration<=?$maxDur"
        if (maxAgeDays > 0) {
            val limit = System.currentTimeMillis() / 1000 - maxAgeDays * 86400L
            parts += "timestamp>=?$limit"
        }
        return if (parts.isEmpty()) null else parts.joinToString(" & ")
    }

    fun summary(): String {
        val p = mutableListOf<String>()
        if (minViews > 0) p += "${short(minViews)}+ views"
        if (maxDur > 0) p += "${maxDur}s tak"
        if (maxAgeDays > 0) p += "$maxAgeDays din"
        return if (p.isEmpty()) "Band (sab videos)" else p.joinToString("  •  ")
    }

    fun short(n: Long) = when {
        n >= 1_000_000 -> "${n / 1_000_000}M"
        n >= 1_000 -> "${n / 1_000}K"
        else -> "$n"
    }
}
