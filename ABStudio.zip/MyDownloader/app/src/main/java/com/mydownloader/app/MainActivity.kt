package com.mydownloader.app

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.fragment.app.FragmentActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** App bhar ki navigation (notification se bhi badli ja sake) */
object NavState {
    var tab by mutableIntStateOf(0)
    var pendingUpload by mutableStateOf<String?>(null)
    var showTour by mutableStateOf(false)
    var showWhatsNew by mutableStateOf(false)
    var showAbout by mutableStateOf(false)
}

class MainActivity : FragmentActivity() {

    private val sharedLink = mutableStateOf("")
    val locked = mutableStateOf(false)
    private val showSplash = mutableStateOf(false)
    private var hiddenAt = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        super.onCreate(savedInstanceState)

        Jobs.init(applicationContext)
        Themes.load(this)
        locked.value = AppLock.enabled(this)
        showSplash.value = savedInstanceState == null   // sirf app khulte waqt

        val perms = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33) {
            perms += Manifest.permission.POST_NOTIFICATIONS
            perms += Manifest.permission.READ_MEDIA_VIDEO
            perms += Manifest.permission.READ_MEDIA_AUDIO
        } else {
            perms += Manifest.permission.READ_EXTERNAL_STORAGE
        }
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.Q) perms += Manifest.permission.WRITE_EXTERNAL_STORAGE
        requestPermissions(perms.toTypedArray(), 1)

        sharedLink.value = extractLink(intent)
        handleNotificationIntent(intent)

        // Pehli dafa: tour. Update ke baad: "Kya naya hai"
        if (!Intro.onboarded(this)) NavState.showTour = true
        else if (Intro.shouldShowWhatsNew(this)) NavState.showWhatsNew = true
        else if (Intro.lastSeen(this) == 0L) Intro.markSeen(this)

        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Neon.Purple, surface = Neon.Card)) {
                Box(Modifier.fillMaxSize()) {
                    AppRoot(sharedLink.value)

                    // 🎬 Reels player (Gallery se)
                    Overlay.player?.let { (list, start) ->
                        val ctx = LocalContext.current
                        val postedSet = remember(Overlay.changes) { Posted.all(ctx) }
                        ReelsPlayer(
                            files = list, startIndex = start, posted = postedSet,
                            onClose = { Overlay.player = null; Overlay.changes++ },
                            onUpload = { f -> uploadFile(ctx, f); Overlay.changes++ },
                            onTogglePosted = { f -> Posted.toggle(ctx, f); Overlay.changes++ },
                            onReels = { f -> requestReels(ctx, f) },
                            onDelete = { f ->
                                if (f.delete()) {
                                    Posted.forget(ctx, f)
                                    val rest = list.filterNot { it.absolutePath == f.absolutePath }
                                    Overlay.player = if (rest.isEmpty()) null
                                    else rest to list.indexOf(f).coerceAtMost(rest.size - 1)
                                    Overlay.changes++
                                }
                            }
                        )
                    }

                    if (NavState.showAbout) AboutScreen(
                        onClose = { NavState.showAbout = false },
                        onTour = { NavState.showAbout = false; NavState.showTour = true },
                        onWhatsNew = { NavState.showWhatsNew = true }
                    )
                    if (NavState.showWhatsNew && !showSplash.value && !NavState.showTour) {
                        WhatsNewDialog { NavState.showWhatsNew = false; Intro.markSeen(this@MainActivity) }
                    }
                    if (NavState.showTour && !showSplash.value) WelcomeTour {
                        NavState.showTour = false
                        Intro.setOnboarded(this@MainActivity, true)
                        Intro.markSeen(this@MainActivity)
                    }
                    ConfettiOverlay()
                    if (locked.value && !showSplash.value) LockScreen { unlock() }
                    if (showSplash.value) AbSplash { showSplash.value = false }

                    // Notification ka "🚀 Upload" (lock khulne ke baad)
                    val ctx = LocalContext.current
                    LaunchedEffect(NavState.pendingUpload, locked.value, showSplash.value) {
                        val path = NavState.pendingUpload
                        if (path != null && !locked.value && !showSplash.value) {
                            NavState.pendingUpload = null
                            NavState.tab = 2
                            val f = java.io.File(path)
                            if (f.exists()) uploadFile(ctx, f)
                        }
                    }
                }
            }
        }
    }

    fun unlock() {
        AppLock.prompt(this, "AB Studio kholein", onOk = { locked.value = false })
    }

    override fun onStop() {
        super.onStop()
        hiddenAt = SystemClock.elapsedRealtime()
    }

    override fun onStart() {
        super.onStart()
        // 30 second se zyada bahar rahe to dobara lock
        if (AppLock.enabled(this) && hiddenAt > 0 && SystemClock.elapsedRealtime() - hiddenAt > 30_000) {
            locked.value = true
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        sharedLink.value = extractLink(intent)
        handleNotificationIntent(intent)
    }

    private fun handleNotificationIntent(i: Intent?) {
        i?.getStringExtra("upload_path")?.let { NavState.pendingUpload = it }
        val t = i?.getIntExtra("open_tab", -1) ?: -1
        if (t >= 0) NavState.tab = t
    }

    private fun extractLink(intent: Intent?): String {
        if (intent?.action != Intent.ACTION_SEND) return ""
        val text = intent.getStringExtra(Intent.EXTRA_TEXT) ?: return ""
        return Regex("https?://\\S+").find(text)?.value ?: text
    }
}

// ===== Lock screen =====
@Composable
fun LockScreen(onUnlock: () -> Unit) {
    val glow = rememberInfiniteTransition(label = "lock")
    val pulse by glow.animateFloat(0.92f, 1.06f, infiniteRepeatable(tween(1400), RepeatMode.Reverse), label = "p")
    LaunchedEffect(Unit) { onUnlock() }
    Column(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Neon.Bg1, Neon.Bg2, Neon.Bg1)))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {},
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Image(
            painterResource(R.drawable.ic_launcher), null,
            modifier = Modifier.size(120.dp).scale(pulse)
        )
        Spacer(Modifier.height(20.dp))
        Text(
            stringResource(R.string.app_name),
            style = TextStyle(brush = Neon.Gradient, fontSize = 30.sp, fontWeight = FontWeight.Black)
        )
        Text("🔒 VIP lock laga hua hai", color = Neon.Muted, fontSize = 14.sp)
        Spacer(Modifier.height(36.dp))
        Box(Modifier.padding(horizontal = 48.dp)) {
            GlowButton("👆  UNLOCK KAREIN", onClick = onUnlock)
        }
    }
}

// ===== Root =====
@Composable
fun AppRoot(sharedLink: String) {
    val context = LocalContext.current
    var tab by NavState::tab
    var showLogin by remember { mutableStateOf(false) }
    var toast by remember { mutableStateOf("") }
    var update by remember { mutableStateOf<UpdateInfo?>(null) }
    var checkNow by remember { mutableIntStateOf(0) }

    LaunchedEffect(sharedLink) { if (sharedLink.isNotBlank()) tab = 0 }
    LaunchedEffect(Unit) { withContext(Dispatchers.IO) { Engine.autoUpdateIfNeeded(context) } }
    LaunchedEffect(checkNow) {
        val info = withContext(Dispatchers.IO) { try { Updater.check(context) } catch (e: Exception) { null } }
        update = info
        if (checkNow > 0 && info == null) toast = "Aap latest version par hain ✓"
    }
    LaunchedEffect(toast) {
        if (toast.isNotEmpty()) { kotlinx.coroutines.delay(3000); toast = "" }
    }
    BackHandler(enabled = showLogin) { showLogin = false }

    Box(Modifier.fillMaxSize()) {
        AuroraBackground()
        Column(Modifier.fillMaxSize()) {
            Box(Modifier.weight(1f)) {
                TabPage(visible = tab == 0) { HomeScreen(sharedLink) }
                TabPage(visible = tab == 1) { CreatorsScreen() }
                TabPage(visible = tab == 2) { GalleryScreen(visible = tab == 2) }
                TabPage(visible = tab == 3) { StatsScreen(visible = tab == 3) }
                TabPage(visible = tab == 4) {
                    SettingsScreen(
                        onLogin = { showLogin = true },
                        onCheckUpdate = { checkNow++ },
                        onToast = { toast = it },
                        onAbout = { NavState.showAbout = true }
                    )
                }
            }
            // Bar: Download, Creators, Gallery, Stats, Pages (AB Uploader), Settings
            VipBottomBar(if (tab == 4) 5 else tab) { i ->
                when {
                    i == 4 -> openPages(context)
                    i == 5 -> tab = 4
                    else -> tab = i
                }
            }
        }

        update?.let { u ->
            AlertDialog(
                onDismissRequest = { update = null },
                containerColor = Neon.Card,
                title = { Text("🎉 Naya update: v${u.version}", color = Neon.Text, fontWeight = FontWeight.Bold) },
                text = {
                    Text(
                        "AB Studio ka naya version aa gaya hai. Download karke install karein, aap ka data salamat rahega.",
                        color = Neon.Muted, fontSize = 13.sp
                    )
                },
                confirmButton = {
                    TextButton(onClick = { Updater.openDownload(context, u); update = null }) {
                        Text("Update karein", color = Neon.Purple, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = { TextButton(onClick = { update = null }) { Text("Baad mein", color = Neon.Muted) } }
            )
        }

        if (showLogin) {
            LoginScreen { msg -> showLogin = false; toast = msg }
        }

        if (toast.isNotEmpty()) {
            Text(
                toast,
                color = Color.White,
                fontSize = 13.sp,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .statusBarsPadding()
                    .padding(top = 12.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Neon.Gradient)
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            )
        }
    }
}

/** 🚀 Pages: Facebook Pages par posting (AB Uploader hissa) */
fun openPages(ctx: android.content.Context) {
    if (Build.VERSION.SDK_INT < 26) {
        android.widget.Toast.makeText(ctx, "Pages ke liye Android 8 ya naya phone chahiye", android.widget.Toast.LENGTH_LONG).show()
        return
    }
    try {
        ctx.startActivity(
            Intent(ctx, com.abuploader.app.ui.UploaderActivity::class.java).putExtra("from_abd", true)
        )
    } catch (e: Exception) { }
}

@Composable
fun TabPage(visible: Boolean, content: @Composable () -> Unit) {
    // Narmi se aana jana (fade + halka slide)
    val a by animateFloatAsState(if (visible) 1f else 0f, tween(260), label = "tab")
    Box(
        Modifier
            .fillMaxSize()
            .offset { if (visible || a > 0.02f) IntOffset.Zero else IntOffset(100_000, 0) }
            .graphicsLayer {
                alpha = a
                translationY = (1f - a) * 24.dp.toPx()
            }
    ) { content() }
}

