package com.abuploader.app

import org.json.JSONArray
import org.json.JSONObject

enum class PostType(val label: String) {
    REEL("Reel"),
    VIDEO("Video"),
    IMAGE("Image"),
    PHOTOS("Multi photo"),
    IMG_STORY("Image story"),
    VIDEO_STORY("Video story");

    val isStory: Boolean get() = this == IMG_STORY || this == VIDEO_STORY
    val needsVideo: Boolean get() = this == REEL || this == VIDEO || this == VIDEO_STORY
    val isMulti: Boolean get() = this == PHOTOS
}

enum class PostStatus { SCHEDULED, POSTED, FAILED }

/** Each Page gets one folder of each kind. */
object FolderKind {
    const val REELS = 0
    const val IMAGES = 1
    const val STORIES = 2
    const val GENERAL = 3 // a plain folder, e.g. the main folder of a Page
    val names = listOf("Reels", "Images", "Stories", "Folder")
    val emojis = listOf("🎬", "🖼️", "📖", "📁")
}

fun JSONObject.str(key: String): String? =
    if (has(key) && !isNull(key)) optString(key) else null

fun JSONArray?.strings(): MutableList<String> {
    val out = mutableListOf<String>()
    if (this == null) return out
    for (i in 0 until length()) out.add(optString(i))
    return out
}

fun List<String>.toJsonArray(): JSONArray {
    val a = JSONArray()
    for (s in this) a.put(s)
    return a
}

class PageAccount(
    val id: String,
    var name: String,
    var source: String = "manual", // manual | facebook | zernio
    var active: Boolean = false,
    var followers: Int = 0,
    var fbId: String? = null, // Facebook Page id
    var token: String? = null, // Page access token (token Pages)
    var zernioKey: String? = null, // Zernio API key (Zernio Pages)
    var zernioAccountId: String? = null,
    var reelsFolderId: String? = null,
    var imagesFolderId: String? = null,
    var storiesFolderId: String? = null,
    var postsPerDay: Int = 0,
    var storiesPerDay: Int = 0,
    var useFixedTimes: Boolean = false,
    var fixedTimes: MutableList<String> = mutableListOf(),
) {
    val viaZernio: Boolean get() = zernioKey != null && zernioAccountId != null
    val viaFacebook: Boolean get() = token != null && fbId != null
    val connected: Boolean get() = viaZernio || viaFacebook
    val connectionLabel: String
        get() = when {
            viaZernio -> "Connected via Zernio"
            viaFacebook -> "Connected to Facebook"
            else -> "Demo Page: nothing is really posted"
        }

    fun folderIdFor(kind: Int): String? = when (kind) {
        FolderKind.REELS -> reelsFolderId
        FolderKind.IMAGES -> imagesFolderId
        else -> storiesFolderId
    }

    fun setFolderFor(kind: Int, id: String?) {
        when (kind) {
            FolderKind.REELS -> reelsFolderId = id
            FolderKind.IMAGES -> imagesFolderId = id
            else -> storiesFolderId = id
        }
    }

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("name", name)
        put("source", source)
        put("active", active)
        put("followers", followers)
        put("fbId", fbId)
        put("token", token)
        put("zernioKey", zernioKey)
        put("zernioAccountId", zernioAccountId)
        put("reelsFolderId", reelsFolderId)
        put("imagesFolderId", imagesFolderId)
        put("storiesFolderId", storiesFolderId)
        put("postsPerDay", postsPerDay)
        put("storiesPerDay", storiesPerDay)
        put("useFixedTimes", useFixedTimes)
        put("fixedTimes", fixedTimes.toJsonArray())
    }

    companion object {
        fun fromJson(j: JSONObject) = PageAccount(
            id = j.optString("id"),
            name = j.optString("name"),
            source = j.str("source") ?: "manual",
            active = j.optBoolean("active", false),
            followers = j.optInt("followers", 0),
            fbId = j.str("fbId"),
            token = j.str("token"),
            zernioKey = j.str("zernioKey"),
            zernioAccountId = j.str("zernioAccountId"),
            reelsFolderId = j.str("reelsFolderId"),
            imagesFolderId = j.str("imagesFolderId"),
            storiesFolderId = j.str("storiesFolderId"),
            postsPerDay = j.optInt("postsPerDay", 0),
            storiesPerDay = j.optInt("storiesPerDay", 0),
            useFixedTimes = j.optBoolean("useFixedTimes", false),
            fixedTimes = j.optJSONArray("fixedTimes").strings(),
        )
    }
}

/**
 * A media file. [path] is a file in the app's storage, or a content:// address of a file
 * in a linked phone folder (read only when a post goes out).
 */
class MediaFile(val path: String, val isVideo: Boolean, val title: String? = null) {
    val name: String get() = title ?: path.substringAfterLast('/').substringAfter('_')
    /** True for files that live outside the app's own copies (phone folder or AB Downloader). */
    val linked: Boolean get() = !path.contains("/files/media/")

    fun toJson(): JSONObject = JSONObject().apply {
        put("path", path)
        put("isVideo", isVideo)
        put("title", title)
    }

    companion object {
        fun fromJson(j: JSONObject) =
            MediaFile(j.optString("path"), j.optBoolean("isVideo", false), j.str("title"))
    }
}

class LibraryFolder(
    val id: String,
    var name: String,
    var kind: Int = FolderKind.REELS,
    var cursor: Int = 0,
    val files: MutableList<MediaFile> = mutableListOf(),
    var parentId: String? = null, // null = top level
    var linkedUri: String? = null, // linked phone folder (tree uri)
    var linkedName: String? = null,
) {
    val videos: Int get() = files.count { it.isVideo }
    val images: Int get() = files.count { !it.isVideo }

    /** Next file in order, wrapping around at the end. */
    fun nextFile(): MediaFile? {
        if (files.isEmpty()) return null
        val f = files[cursor % files.size]
        cursor = (cursor + 1) % files.size
        return f
    }

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("name", name)
        put("kind", kind)
        put("cursor", cursor)
        put("parentId", parentId)
        put("linkedUri", linkedUri)
        put("linkedName", linkedName)
        val a = JSONArray()
        for (f in files) a.put(f.toJson())
        put("files", a)
    }

    companion object {
        fun fromJson(j: JSONObject): LibraryFolder {
            val files = mutableListOf<MediaFile>()
            val a = j.optJSONArray("files")
            if (a != null) {
                for (i in 0 until a.length()) {
                    val o = a.optJSONObject(i) ?: continue
                    files.add(MediaFile.fromJson(o))
                }
            }
            return LibraryFolder(
                id = j.optString("id"),
                name = j.optString("name"),
                kind = j.optInt("kind", 0),
                cursor = j.optInt("cursor", 0),
                files = files,
                parentId = j.str("parentId"),
                linkedUri = j.str("linkedUri"),
                linkedName = j.str("linkedName"),
            )
        }
    }
}

class ScheduledPost(
    val id: String,
    val pageId: String,
    val type: PostType,
    val media: List<String>,
    val caption: String,
    var whenMs: Long,
    val firstComment: String? = null,
    val auto: Boolean = false, // created by daily autopilot
    var status: PostStatus = PostStatus.SCHEDULED,
    var error: String? = null,
) {
    fun withMedia(paths: List<String>) =
        ScheduledPost(id, pageId, type, paths, caption, whenMs, firstComment, auto, status, error)

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("pageId", pageId)
        put("type", type.name)
        put("media", media.toJsonArray())
        put("caption", caption)
        put("when", whenMs)
        put("firstComment", firstComment)
        put("auto", auto)
        put("status", status.name)
        put("error", error)
    }

    companion object {
        fun fromJson(j: JSONObject) = ScheduledPost(
            id = j.optString("id"),
            pageId = j.optString("pageId"),
            type = PostType.entries.firstOrNull { it.name == j.optString("type") } ?: PostType.IMAGE,
            media = j.optJSONArray("media").strings(),
            caption = j.optString("caption"),
            whenMs = j.optLong("when", 0L),
            firstComment = j.str("firstComment"),
            auto = j.optBoolean("auto", false),
            status = PostStatus.entries.firstOrNull { it.name == j.optString("status") }
                ?: PostStatus.SCHEDULED,
            error = j.str("error"),
        )
    }
}

/** One Zernio account (API key). A free account has 2 channels; paid plans can raise [limit]. */
class ZernioKey(
    val key: String,
    var name: String,
    var limit: Int = 2,
    var used: Int = 0, // connected channels (accounts) in this Zernio account
    var profileId: String? = null,
) {
    val left: Int get() = (limit - used).coerceAtLeast(0)
    val last4: String get() = key.takeLast(4)

    fun toJson(): JSONObject = JSONObject().apply {
        put("key", key)
        put("name", name)
        put("limit", limit)
        put("used", used)
        put("profileId", profileId)
    }

    companion object {
        fun fromJson(j: JSONObject) = ZernioKey(
            key = j.optString("key"),
            name = j.str("name") ?: "Zernio",
            limit = j.optInt("limit", 2),
            used = j.optInt("used", 0),
            profileId = j.str("profileId"),
        )

        /** Accepts the new object form and the old plain-string form. */
        fun listFrom(a: JSONArray?): MutableList<ZernioKey> {
            val out = mutableListOf<ZernioKey>()
            if (a == null) return out
            for (i in 0 until a.length()) {
                val o = a.optJSONObject(i)
                if (o != null) {
                    out.add(fromJson(o))
                } else {
                    val s = a.optString(i)
                    if (s.isNotBlank()) out.add(ZernioKey(s, "Key ${i + 1}"))
                }
            }
            return out
        }
    }
}

/** A Zernio connect link; Zernio keeps it valid for 30 minutes. */
class ConnectLink(val url: String, val key: String, val createdAt: Long, val baseUsed: Int) {
    val expiresAt: Long get() = createdAt + 30 * 60_000L
    val expired: Boolean get() = System.currentTimeMillis() > expiresAt

    fun toJson(): JSONObject = JSONObject().apply {
        put("url", url)
        put("key", key)
        put("createdAt", createdAt)
        put("baseUsed", baseUsed)
    }

    companion object {
        fun fromJson(j: JSONObject) = ConnectLink(
            j.optString("url"),
            j.optString("key"),
            j.optLong("createdAt"),
            j.optInt("baseUsed"),
        )
    }
}

class Settings(
    var userName: String = "Creator",
    var engineOn: Boolean = false,
    var adsterraKeys: List<String> = emptyList(),
    var zernioKeys: List<ZernioKey> = emptyList(),
    var permanentLink: String = "", // Cloudflare Worker url, see PermanentLinkScreen
    var autoFirstComment: Boolean = false,
    var useOriginalCaption: Boolean = true, // AB Downloader videos keep their TikTok/IG caption
    var startHour: Int = 8, // autopilot window
    var endHour: Int = 22,
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("userName", userName)
        put("engineOn", engineOn)
        put("adsterraKeys", adsterraKeys.toJsonArray())
        put("zernioKeys", JSONArray().apply { zernioKeys.forEach { put(it.toJson()) } })
        put("permanentLink", permanentLink)
        put("autoFirstComment", autoFirstComment)
        put("useOriginalCaption", useOriginalCaption)
        put("startHour", startHour)
        put("endHour", endHour)
    }

    companion object {
        fun fromJson(j: JSONObject) = Settings(
            userName = j.str("userName") ?: "Creator",
            engineOn = j.optBoolean("engineOn", false),
            adsterraKeys = j.optJSONArray("adsterraKeys").strings(),
            zernioKeys = ZernioKey.listFrom(j.optJSONArray("zernioKeys")),
            permanentLink = j.str("permanentLink") ?: "",
            autoFirstComment = j.optBoolean("autoFirstComment", false),
            useOriginalCaption = j.optBoolean("useOriginalCaption", true),
            startHour = j.optInt("startHour", 8),
            endHour = j.optInt("endHour", 22),
        )
    }
}
