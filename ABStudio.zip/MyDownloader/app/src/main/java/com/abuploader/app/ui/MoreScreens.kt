package com.abuploader.app.ui

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import com.abuploader.app.ZernioKey
import com.abuploader.app.PostStatus
import com.abuploader.app.Store
import kotlinx.coroutines.launch

/** Guide texts shown by the Guide button on each screen. */
object Guides {
    const val HOME =
        "Dashboard shows your Adsterra earnings, the posting engine, totals and the last 14 days.\n\n" +
            "Start the engine to let AB Uploader post your daily plan all day, also with the app closed. " +
            "Allow \"no battery limits\" when the phone asks."
    const val PAGES =
        "Turn on the Pages you want to post to. Tap a Page to set posts per day, stories per day, " +
            "fixed times and the folders it posts from. Changes re-plan today's autopilot posts."
    const val POST =
        "Schedule a post: pick the type, choose media from the phone or the Library, write one or more captions " +
            "(empty line between them) and post now or at a time. It goes to every Page that is turned on.\n\n" +
            "Bulk Daily: one daily plan for all Pages that are turned on, for example 3 Reels a day on 50 Pages."
    const val LIBRARY =
        "\"Page folder set\" makes a main folder for every Page (with the Page's name) and inside it Images, Reels and " +
            "Stories sub-folders, already linked to that Page. Open a folder: \"Add from phone\" adds files, " +
            "\"Sub-folder\" makes more folders, and the ⋮ menu can link a phone folder so new files you put there " +
            "appear automatically. The engine takes the next file each time and starts again at the end."
    const val CONNECT =
        "Facebook token: create a Facebook app, get a token in Graph API Explorer and paste it. " +
            "Add your App ID and App Secret so the token does not expire.\n\n" +
            "Zernio: add API keys from zernio.com (a free account has 2 channels). Then share the connect link: " +
            "a Page owner opens it, picks a Page, and the Page appears here after Refresh. Each link works for 30 minutes."
    const val ADS =
        "Add one or many read-only Adsterra publisher API keys (Adsterra > API). " +
            "See earnings, views, CPM, top placements, websites and countries, and copy your Smartlinks."
    const val QUEUE =
        "Upcoming shows what will be posted. History shows what was posted or failed and why. " +
            "\"Retry failed\" sends failed posts again now."

    val all = listOf(
        "1. Connect your Pages" to "More > Connections. Use a Facebook token (all Pages you manage are imported) or Zernio API keys.",
        "2. Set up folders" to LIBRARY,
        "3. Turn Pages on" to PAGES,
        "4. Post once" to "Post tab > Schedule a post. Pick the type, media and captions, then Post now or Schedule.",
        "5. Daily autopilot" to "Post tab > Bulk Daily for many Pages at once, or tap a Page for its own plan. Then start the engine on Home.",
        "6. Captions and comments" to "Paste several captions with an empty line between them and they rotate. First comments work the same way.",
        "7. Keep it running" to "More > Reliable background posting. Allow notifications, remove battery limits and turn on Auto-start if your phone has it.",
        "8. Check results" to "More > Queue & history and Analytics. Failed posts show the reason and can be retried.",
    )
}

@Composable
fun MoreScreen() {
    Store.rev
    val st = Store.settings
    var nameOpen by remember { mutableStateOf(false) }
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp),
    ) {
        ScreenTitle("More")
        AppCard(onClick = { nameOpen = true }) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(C.card2),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(st.userName.take(1).uppercase().ifEmpty { "?" }, color = C.amber, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                }
                Spacer(Modifier.width(16.dp))
                Column {
                    Text(st.userName, color = C.text, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                    Text("Tap to change your name", color = C.muted)
                }
            }
        }
        MenuRow(Icons.Filled.Share, C.amber, "Connections", "${Store.pages.size} Pages · Facebook token or Zernio API keys") {
            Nav.push(Route.Connections)
        }
        MenuRow(Icons.Filled.Settings, C.orange, "Autopilot settings", "Posting hours, captions and first comments") {
            Nav.push(Route.Settings)
        }
        MenuRow(Icons.Filled.DateRange, C.orange, "Queue & history", "${Store.upcoming.size} upcoming · ${Store.failedCount} failed") {
            Nav.push(Route.Queue)
        }
        MenuRow(Icons.Filled.Star, C.green, "Analytics", "Posts, failures and followers per Page") {
            Nav.push(Route.Analytics)
        }
        MenuRow(Icons.Filled.ShoppingCart, C.orange, "Adsterra earnings", "Revenue and views from all your Adsterra accounts") {
            Nav.push(Route.Ads)
        }
        MenuRow(Icons.Filled.Notifications, C.blue, "Reliable background posting", "Keep posting with the app closed") {
            Nav.push(Route.Background)
        }
        MenuRow(Icons.Filled.PlayArrow, C.blue, "Guides", "Learn AB Uploader step by step") {
            Nav.push(Route.Guides)
        }
        Text("Pages (AB Uploader) · inside AB Downloader", color = C.muted, modifier = Modifier.padding(vertical = 14.dp))
    }
    if (nameOpen) {
        InputDialog("Your name", "Name", st.userName, onDismiss = { nameOpen = false }) {
            if (it.isNotEmpty()) Store.setUserName(it)
            nameOpen = false
        }
    }
}

// ---------- connections ----------
@Composable
fun ConnectionsScreen() {
    Store.rev
    var demoOpen by remember { mutableStateOf(false) }
    SubScreen("Connections", guide = Guides.CONNECT) {
        MenuRow(Icons.Filled.Person, C.blue, "Facebook token", "Import all your Pages with your own Facebook app") {
            Nav.push(Route.FacebookConnect)
        }
        val keys = Store.settings.zernioKeys
        MenuRow(
            Icons.Filled.Lock,
            C.orange,
            "Zernio",
            if (keys.isEmpty()) {
                "API keys and a connect link for Page owners"
            } else {
                "${keys.size} key(s) · ${Store.pages.count { it.viaZernio }} Page(s) · ${Store.zernioChannelsLeft} channels left"
            },
        ) { Nav.push(Route.ZernioConnect) }
        MenuRow(Icons.Filled.AddCircle, C.green, "Add a demo Page", "For trying the app: posts are simulated") {
            demoOpen = true
        }
        Text(
            "${Store.pages.size} Page(s): ${Store.pages.count { it.viaFacebook }} via Facebook token, " +
                "${Store.pages.count { it.viaZernio }} via Zernio, ${Store.pages.count { !it.connected }} demo",
            color = C.muted,
            modifier = Modifier.padding(top = 8.dp),
        )
    }
    if (demoOpen) {
        InputDialog("Demo Page name", "My Page", onDismiss = { demoOpen = false }) {
            if (it.isNotEmpty()) Store.addPage(it)
            demoOpen = false
        }
    }
}

@Composable
fun FacebookConnectScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var token by remember { mutableStateOf("") }
    var appId by remember { mutableStateOf("") }
    var secret by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    SubScreen("Facebook token", guide = Guides.CONNECT) {
        Text(
            "How to get a token (one time, in a browser):\n" +
                "1. Go to developers.facebook.com and create an app (type: Business).\n" +
                "2. Open Tools > Graph API Explorer and pick your app.\n" +
                "3. Add permissions: pages_show_list, pages_read_engagement, pages_manage_posts, pages_manage_engagement.\n" +
                "4. Tap Generate Access Token and log in with the account that manages your Pages.\n" +
                "5. Paste the token below, plus your App ID and App Secret (App settings > Basic). " +
                "With them the Page tokens do not expire.",
            color = C.muted,
            lineHeight = 22.sp,
        )
        Field(token, { token = it }, "User access token", minLines = 2, maxLines = 4)
        Field(appId, { appId = it }, "App ID (recommended)")
        Field(secret, { secret = it }, "App Secret (recommended, not saved)", secret = true)
        error?.let { Text(it, color = C.red, modifier = Modifier.padding(top = 6.dp)) }
        GradientButton(
            label = if (busy) "Connecting…" else "Import my Pages",
            enabled = !busy,
            onClick = {
                if (token.isBlank()) {
                    error = "Paste your access token first."
                } else {
                    busy = true
                    error = null
                    scope.launch {
                        try {
                            val n = Store.connectFacebook(token, appId, secret)
                            toast(ctx, "$n Page(s) imported")
                            Nav.pop()
                        } catch (e: Exception) {
                            error = e.message ?: e.toString()
                        } finally {
                            busy = false
                        }
                    }
                }
            },
        )
        Text("Tokens stay on this phone, encrypted. Never share them.", color = C.muted, fontSize = 13.sp)
    }
}

@Composable
fun ZernioConnectScreen() {
    Store.rev
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val clip = LocalClipboardManager.current
    var busy by remember { mutableStateOf(false) }
    var linkBusy by remember { mutableStateOf(false) }
    var addOpen by remember { mutableStateOf(false) }
    var removeKey by remember { mutableStateOf<String?>(null) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }

    fun refresh(only: String? = null) {
        if (busy) return
        busy = true
        scope.launch {
            try {
                val failed = Store.refreshZernio(only)
                if (failed > 0) toast(ctx, "$failed key(s) could not be read. Check the key.")
            } finally {
                busy = false
            }
        }
    }

    fun newLink() {
        if (linkBusy) return
        linkBusy = true
        scope.launch {
            try {
                Store.createConnectLink()
                toast(ctx, "New link ready, valid for 30 minutes")
            } catch (e: Exception) {
                toast(ctx, e.message ?: e.toString())
            } finally {
                linkBusy = false
            }
        }
    }

    fun copyText(url: String) {
        clip.setText(AnnotatedString(url))
        toast(ctx, "Link copied")
    }

    fun shareText(url: String) {
        val send = Intent(Intent.ACTION_SEND)
            .setType("text/plain")
            .putExtra(Intent.EXTRA_TEXT, "Connect your Facebook Page: " + url)
        try {
            ctx.startActivity(Intent.createChooser(send, "Share connect link"))
        } catch (_: Exception) {
        }
    }

    /** Uses the permanent link, or makes a fresh 30-minute link first. */
    fun withLink(action: (String) -> Unit) {
        val perm = Store.settings.permanentLink
        if (perm.isNotEmpty()) {
            action(perm)
            return
        }
        if (linkBusy) return
        linkBusy = true
        scope.launch {
            try {
                action(Store.createConnectLink().url)
            } catch (e: Exception) {
                toast(ctx, e.message ?: e.toString())
            } finally {
                linkBusy = false
            }
        }
    }

    // Pages connected through a link show up after a refresh; check when the screen opens.
    LaunchedEffect(Unit) {
        if (Store.settings.zernioKeys.isNotEmpty()) refresh()
    }
    LaunchedEffect(Unit) {
        while (true) {
            kotlinx.coroutines.delay(20_000)
            now = System.currentTimeMillis()
        }
    }

    val keys = Store.settings.zernioKeys
    val link = Store.connectLink
    val linkValid = link != null && now < link.expiresAt

    SubScreen(
        "Zernio",
        guide = Guides.CONNECT,
        actions = {
            IconButton(onClick = { refresh() }) {
                Icon(Icons.Filled.Refresh, contentDescription = "Refresh", tint = C.orange)
            }
        },
    ) {
        // ---------- connect link ----------
        val perm = Store.settings.permanentLink
        val shareUrl: String? = when {
            perm.isNotEmpty() -> perm
            linkValid -> link?.url
            else -> null
        }
        AppCard {
            Row(verticalAlignment = Alignment.Top) {
                IconTile(Icons.Filled.Share, C.blue)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text("Connect link", color = C.text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "Share it with any Page owner. Each use connects one Page through a key that still has room.",
                        color = C.muted,
                        fontSize = 13.sp,
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "${Store.zernioChannelsLeft}",
                    color = if (Store.zernioChannelsLeft > 0) C.green else C.red,
                    fontSize = 34.sp,
                    fontWeight = FontWeight.ExtraBold,
                )
                Spacer(Modifier.width(8.dp))
                Text("channels left", color = C.muted, fontSize = 16.sp, modifier = Modifier.weight(1f))
                val status = when {
                    perm.isNotEmpty() -> "Permanent link"
                    link == null -> "No link yet"
                    linkValid -> "${((link.expiresAt - now) / 60_000L).coerceAtLeast(1)} min left · ${Store.connectLinkConnected()} connected"
                    else -> "Expired · ${Store.connectLinkConnected()} connected"
                }
                Text(status, color = if (perm.isNotEmpty()) C.green else C.muted, fontSize = 12.sp)
            }
            Spacer(Modifier.height(10.dp))
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(C.bg)
                    .padding(start = 12.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    when {
                        shareUrl != null -> shareUrl
                        linkBusy -> "Making a link…"
                        link == null -> "Tap \"Create a new link\""
                        else -> "This link expired. Create a new one."
                    },
                    color = if (shareUrl != null) C.amber else C.muted,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f),
                )
                IconButton(onClick = { withLink { copyText(it) } }) {
                    Icon(Icons.Filled.Check, contentDescription = "Copy", tint = C.amber)
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                GradientButton(
                    label = if (linkBusy) "Making link…" else "Copy link",
                    modifier = Modifier.weight(1f),
                    enabled = !linkBusy && (perm.isNotEmpty() || keys.isNotEmpty()),
                    onClick = { withLink { copyText(it) } },
                )
                OutlineButton("Share", {
                    if (perm.isEmpty() && keys.isEmpty()) {
                        toast(ctx, "Add a Zernio key first")
                    } else {
                        withLink { shareText(it) }
                    }
                }, Modifier.weight(1f))
            }
            if (perm.isEmpty()) {
                Text(
                    if (linkBusy) "Working…" else "Create a new link",
                    color = C.amber,
                    fontSize = 14.sp,
                    modifier = Modifier
                        .clickable(enabled = !linkBusy && keys.isNotEmpty()) { newLink() }
                        .padding(vertical = 8.dp),
                )
                Text(
                    "Every Copy or Share makes a fresh link through a key with room. Each link works for 30 minutes, " +
                        "so the Page owner should open it right away. For a link that never expires, set up a permanent link once.",
                    color = C.muted,
                    fontSize = 12.sp,
                )
                Text(
                    "Make a permanent link (free)",
                    color = C.amber,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier
                        .clickable { Nav.push(Route.PermanentLink) }
                        .padding(vertical = 8.dp),
                )
            } else {
                Text(
                    "This link always works and picks a key that still has a free channel.",
                    color = C.muted,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(top = 6.dp),
                )
                Text(
                    "Permanent link settings",
                    color = C.amber,
                    fontSize = 14.sp,
                    modifier = Modifier
                        .clickable { Nav.push(Route.PermanentLink) }
                        .padding(vertical = 8.dp),
                )
            }
        }

        // ---------- keys ----------
        SectionLabel("API KEYS", "Add key") { addOpen = true }
        if (keys.isEmpty()) {
            EmptyState(Icons.Filled.Lock, "No keys yet", "Tap \"Add key\" and paste a key from zernio.com.")
        }
        keys.forEach { zk -> ZernioKeyCard(zk, busy, onRefresh = { refresh(zk.key) }, onRemove = { removeKey = zk.key }) }

        // ---------- how it works ----------
        SectionLabel("HOW IT WORKS")
        AppCard {
            val steps = listOf(
                "Create free accounts at zernio.com. Each one includes 2 channels (one Facebook Page is one channel).",
                "Copy the API key from Dashboard → API keys and add it here. Add as many keys as you need.",
                "Share your connect link. It always opens through a key that still has a free channel.",
                "When the Page is connected, it appears in AB Uploader automatically. Use Refresh if you don't see it yet.",
                "On a paid Zernio plan, raise that key's limit with the + button.",
            )
            steps.forEachIndexed { i, s ->
                Row(Modifier.padding(vertical = 6.dp)) {
                    Box(
                        Modifier
                            .size(26.dp)
                            .clip(CircleShape)
                            .background(C.orange),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text("${i + 1}", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.width(12.dp))
                    Text(s, color = C.text, fontSize = 14.sp, lineHeight = 20.sp, modifier = Modifier.weight(1f))
                }
            }
            Text(
                "Open zernio.com",
                color = C.amber,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier
                    .clickable {
                        try {
                            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://zernio.com")))
                        } catch (_: Exception) {
                        }
                    }
                    .padding(top = 10.dp, bottom = 4.dp),
            )
        }
    }

    if (addOpen) {
        AddZernioKeyDialog(onDismiss = { addOpen = false }) { name, key ->
            addOpen = false
            busy = true
            scope.launch {
                try {
                    val n = Store.connectZernio(key, name)
                    toast(ctx, if (n == 0) "Key added. Share your connect link to add Pages." else "$n Page(s) imported from Zernio")
                    if (Store.settings.permanentLink.isNotEmpty()) {
                        toast(ctx, "Permanent link: update ZERNIO_KEYS in Cloudflare too")
                    }
                } catch (e: Exception) {
                    toast(ctx, e.message ?: e.toString())
                } finally {
                    busy = false
                }
            }
        }
    }
    removeKey?.let { k ->
        ConfirmDialog(
            title = "Remove this key?",
            text = "Its Pages and their scheduled posts are removed from AB Uploader. Nothing changes on Zernio.",
            yes = "Remove",
            onDismiss = { removeKey = null },
            onYes = {
                removeKey = null
                Store.removeZernioKey(k)
            },
        )
    }
}

@Composable
private fun ZernioKeyCard(zk: ZernioKey, busy: Boolean, onRefresh: () -> Unit, onRemove: () -> Unit) {
    AppCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(C.orange),
                contentAlignment = Alignment.Center,
            ) {
                Text(zk.name.take(1).uppercase().ifEmpty { "Z" }, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(zk.name, color = C.text, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Text("Key …${zk.last4} · ${Store.zernioPageCount(zk.key)} Pages in AB Uploader", color = C.muted, fontSize = 13.sp)
            }
            if (zk.left > 0) Pill("${zk.left} left", C.green) else Pill("Full", C.red)
        }
        Spacer(Modifier.height(12.dp))
        val frac = if (zk.limit <= 0) 1f else (zk.used.toFloat() / zk.limit).coerceIn(0f, 1f)
        Box(
            Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp))
                .background(C.card2),
        ) {
            if (frac > 0f) {
                Box(
                    Modifier
                        .fillMaxWidth(frac)
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(if (zk.left > 0) C.green else C.red),
                )
            }
        }
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("${zk.used} of ${zk.limit} channels used", color = C.muted, fontSize = 13.sp, modifier = Modifier.weight(1f))
            Text("Limit", color = C.muted, fontSize = 13.sp)
            Text(
                "−",
                color = C.amber,
                fontSize = 22.sp,
                modifier = Modifier
                    .clickable { if (zk.limit > 1) Store.setZernioLimit(zk.key, zk.limit - 1) }
                    .padding(horizontal = 10.dp),
            )
            Text("${zk.limit}", color = C.text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Text(
                "+",
                color = C.amber,
                fontSize = 22.sp,
                modifier = Modifier
                    .clickable { Store.setZernioLimit(zk.key, zk.limit + 1) }
                    .padding(horizontal = 10.dp),
            )
            IconButton(onClick = { if (!busy) onRefresh() }) {
                Icon(Icons.Filled.Refresh, contentDescription = "Refresh key", tint = C.amber)
            }
            IconButton(onClick = onRemove) {
                Icon(Icons.Filled.Delete, contentDescription = "Remove key", tint = C.muted)
            }
        }
    }
}

@Composable
private fun AddZernioKeyDialog(onDismiss: () -> Unit, onAdd: (String, String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var key by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = { if (key.isNotBlank()) onAdd(name.trim(), key.trim()) }, enabled = key.isNotBlank()) {
                Text("Add")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
        title = { Text("Add Zernio key") },
        text = {
            Column {
                Text(
                    "zernio.com → Dashboard → API keys → Create API key. A free account has 2 channels.",
                    color = C.muted,
                    fontSize = 13.sp,
                )
                Field(name, { name = it }, "Name (for example ab1)")
                Field(key, { key = it }, "API key")
            }
        },
        containerColor = C.card,
    )
}

// ---------- autopilot settings ----------
@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    val st = Store.settings
    var start by remember { mutableIntStateOf(st.startHour) }
    var end by remember { mutableIntStateOf(st.endHour) }
    var autoComment by remember { mutableStateOf(st.autoFirstComment) }
    var captions by remember { mutableStateOf(Store.captionPool.joinToString("\n\n")) }
    var comments by remember { mutableStateOf(Store.commentPool.joinToString("\n\n")) }
    SubScreen("Autopilot settings") {
        SectionLabel("Posting hours")
        AppCard {
            Text("Evenly spread posts go out between these hours.", color = C.muted, fontSize = 14.sp)
            Stepper("Start hour", start, { start = it }, min = 0, max = 23)
            Stepper("End hour", end, { end = it }, min = 1, max = 24)
            Text("From %02d:00 to %02d:00".format(start, end.coerceAtLeast(start + 1)), color = C.amber)
        }
        SwitchRow(
            "Original caption for AB Downloader videos",
            Store.settings.useOriginalCaption,
            { Store.setUseOriginalCaption(it) },
            subtitle = "TikTok/IG caption with \"Part 1, 2…\" (from Downloader settings). Off: caption pool",
        )
        SwitchRow(
            "Auto first comment",
            autoComment,
            { autoComment = it },
            subtitle = "Add a comment from the pool to every autopilot post",
        )
        SectionLabel("Caption pool")
        Field(captions, { captions = it }, "Captions, empty line between them", minLines = 3, maxLines = 8)
        SectionLabel("First comment pool")
        Field(comments, { comments = it }, "Comments, empty line between them", minLines = 2, maxLines = 6)
        GradientButton(
            label = "Save",
            onClick = {
                Store.setPools(splitBlocks(captions), splitBlocks(comments))
                Store.setAutopilot(start, end.coerceAtLeast(start + 1).coerceAtMost(24), autoComment)
                toast(ctx, "Saved")
                Nav.pop()
            },
        )
    }
}

// ---------- queue & history ----------
@Composable
fun QueueScreen() {
    Store.rev
    val ctx = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    SubScreen("Queue & history", guide = Guides.QUEUE) {
        Segmented(listOf("Upcoming (${Store.upcoming.size})", "History (${Store.history.size})"), tab) { tab = it }
        if (tab == 0) {
            val list = Store.upcoming
            if (list.isEmpty()) {
                EmptyState(Icons.Filled.DateRange, "Nothing upcoming", "Schedule a post or start the daily autopilot.")
            }
            list.take(300).forEach { p ->
                AppCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.weight(1f)) { PostLine(p) }
                        IconButton(onClick = { Store.cancelPost(p.id) }) {
                            Icon(Icons.Filled.Delete, contentDescription = "Cancel", tint = C.red)
                        }
                    }
                    if (p.caption.isNotBlank()) Text(p.caption, color = C.muted, fontSize = 13.sp, maxLines = 2)
                }
            }
        } else {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlineButton("Retry failed", {
                    val n = Store.retryFailed()
                    toast(ctx, "$n post(s) sent again")
                    com.abuploader.app.Engine.kick(ctx)
                }, Modifier.weight(1f), C.amber)
                OutlineButton("Clear history", { Store.clearHistory() }, Modifier.weight(1f), C.red)
            }
            val list = Store.history
            if (list.isEmpty()) EmptyState(Icons.Filled.DateRange, "No history yet", "Posted and failed posts show up here.")
            list.take(300).forEach { p ->
                AppCard {
                    PostLine(p)
                    val err = p.error
                    if (p.status == PostStatus.FAILED && err != null) Text(err, color = C.red, fontSize = 13.sp)
                }
            }
        }
    }
}

// ---------- analytics ----------
@Composable
fun AnalyticsScreen() {
    Store.rev
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    SubScreen(
        "Analytics",
        actions = {
            IconButton(onClick = {
                if (!busy) {
                    busy = true
                    scope.launch {
                        try {
                            val n = Store.refreshFollowers()
                            toast(ctx, "Followers updated for $n Page(s)")
                        } finally {
                            busy = false
                        }
                    }
                }
            }) { Icon(Icons.Filled.Refresh, contentDescription = "Refresh followers", tint = C.amber) }
        },
    ) {
        AppCard {
            Text("Last 14 days", color = C.text, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(8.dp))
            PostsChart()
        }
        if (busy) Text("Updating followers…", color = C.muted)
        if (Store.pages.isEmpty()) {
            EmptyState(Icons.Filled.Star, "No data yet", "Add Pages and start posting to see results here.")
        }
        val weekAgo = System.currentTimeMillis() - 7 * 86_400_000L
        Store.pages.forEach { page ->
            val mine = Store.posts.filter { it.pageId == page.id }
            val ok = mine.count { it.status == PostStatus.POSTED }
            val bad = mine.count { it.status == PostStatus.FAILED }
            val week = mine.count { it.status == PostStatus.POSTED && it.whenMs >= weekAgo }
            AppCard {
                Text(page.name, color = C.text, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Row {
                    Text("%,d followers".format(page.followers), color = C.muted, modifier = Modifier.weight(1f))
                    Text("$ok posted", color = C.green)
                    Spacer(Modifier.width(12.dp))
                    Text("$bad failed", color = C.red)
                }
                Text("$week posted in the last 7 days", color = C.muted, fontSize = 13.sp)
            }
        }
    }
}

// ---------- background ----------
@Composable
fun BackgroundScreen() {
    val ctx = LocalContext.current
    val notif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        toast(ctx, if (ok) "Notifications allowed" else "Notifications are off")
    }
    val pm = ctx.getSystemService(PowerManager::class.java)
    val ignoring = pm?.isIgnoringBatteryOptimizations(ctx.packageName) == true
    SubScreen("Reliable background posting") {
        Text(
            "When the engine is on, AB Uploader shows a small notification and keeps posting with the screen off " +
                "or the app closed. It also wakes up at each post time and starts again after a phone restart.",
            color = C.muted,
            lineHeight = 22.sp,
        )
        Spacer(Modifier.height(8.dp))
        GradientButton(
            label = "Allow notifications",
            icon = Icons.Filled.Notifications,
            onClick = {
                if (Build.VERSION.SDK_INT >= 33) notif.launch(Manifest.permission.POST_NOTIFICATIONS) else toast(ctx, "Already allowed")
            },
        )
        GradientButton(
            label = if (ignoring) "Battery limits removed ✓" else "Remove battery limits",
            onClick = { askBatteryExemption(ctx) },
        )
        OutlineButton("Open app settings (Auto-start, battery)", {
            try {
                ctx.startActivity(
                    Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS).setData(Uri.parse("package:" + ctx.packageName)),
                )
            } catch (_: Exception) {
            }
        }, Modifier.fillMaxWidth(), C.amber)
        SectionLabel("Phone tips")
        AppCard {
            Text(
                "1. Turn on Auto-start for AB Downloader (Xiaomi, Oppo, Vivo, Realme, Infinix, Tecno and similar phones have it in Settings > Apps).\n" +
                    "2. Set battery use for AB Downloader to \"No restrictions\".\n" +
                    "3. Some phones close apps that are swiped away. If posts stop, lock AB Downloader in the recent apps list.",
                color = C.muted,
                lineHeight = 22.sp,
            )
        }
    }
}

// ---------- guides ----------
@Composable
fun GuidesScreen() {
    var open by remember { mutableIntStateOf(-1) }
    SubScreen("Guides") {
        Guides.all.forEachIndexed { i, (title, text) ->
            AppCard(onClick = { open = if (open == i) -1 else i }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(title, color = C.text, fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Icon(
                        if (open == i) Icons.Filled.KeyboardArrowUp else Icons.Filled.KeyboardArrowDown,
                        contentDescription = null,
                        tint = C.muted,
                    )
                }
                if (open == i) {
                    Spacer(Modifier.height(8.dp))
                    Text(text, color = C.muted, lineHeight = 22.sp)
                }
            }
        }
    }
}
