package com.abuploader.app

import java.io.File
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Small blocking HTTP client. Always call it from a background thread. */
object Http {
    class Resp(val code: Int, val body: String) {
        val ok: Boolean get() = code in 200..299
    }

    private const val CONNECT_MS = 30_000
    private const val UPLOAD_READ_MS = 15 * 60_000

    fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    fun withQuery(base: String, params: Map<String, String>): String {
        if (params.isEmpty()) return base
        val q = params.entries.joinToString("&") { "${enc(it.key)}=${enc(it.value)}" }
        return if (base.contains('?')) "$base&$q" else "$base?$q"
    }

    private fun open(
        url: String,
        method: String,
        headers: Map<String, String>,
        readMs: Int,
    ): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = CONNECT_MS
        c.readTimeout = readMs
        c.instanceFollowRedirects = true
        for ((k, v) in headers) c.setRequestProperty(k, v)
        return c
    }

    private fun read(c: HttpURLConnection): Resp {
        try {
            val code = c.responseCode
            val stream: InputStream? = if (code in 200..299) c.inputStream else c.errorStream
            val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            return Resp(code, body)
        } finally {
            c.disconnect()
        }
    }

    private fun sendBytes(c: HttpURLConnection, bytes: ByteArray) {
        c.doOutput = true
        c.setFixedLengthStreamingMode(bytes.size)
        c.outputStream.use { it.write(bytes) }
    }

    fun get(url: String, headers: Map<String, String> = emptyMap()): Resp {
        val c = open(url, "GET", headers, 30_000)
        return read(c)
    }

    fun postForm(
        url: String,
        fields: Map<String, String>,
        headers: Map<String, String> = emptyMap(),
    ): Resp {
        val body = fields.entries.joinToString("&") { "${enc(it.key)}=${enc(it.value)}" }
        val c = open(url, "POST", headers + ("Content-Type" to "application/x-www-form-urlencoded"), 120_000)
        sendBytes(c, body.toByteArray(Charsets.UTF_8))
        return read(c)
    }

    fun sendJson(
        url: String,
        method: String,
        json: String,
        headers: Map<String, String> = emptyMap(),
        readMs: Int = 120_000,
    ): Resp {
        val c = open(url, method, headers + ("Content-Type" to "application/json"), readMs)
        sendBytes(c, json.toByteArray(Charsets.UTF_8))
        return read(c)
    }

    /** Streams a file as the raw request body (no memory copy of the whole file). */
    fun sendFile(
        url: String,
        method: String,
        file: File,
        headers: Map<String, String> = emptyMap(),
    ): Resp {
        val c = open(url, method, headers, UPLOAD_READ_MS)
        c.doOutput = true
        c.setFixedLengthStreamingMode(file.length())
        c.outputStream.use { out -> file.inputStream().use { it.copyTo(out, 64 * 1024) } }
        return read(c)
    }

    /** multipart/form-data with text fields and one file. */
    fun multipart(
        url: String,
        fields: Map<String, String>,
        fileField: String,
        file: File,
        mime: String,
    ): Resp {
        val boundary = "----ABUploader" + System.currentTimeMillis()
        val head = StringBuilder()
        for ((k, v) in fields) {
            head.append("--").append(boundary).append("\r\n")
            head.append("Content-Disposition: form-data; name=\"").append(k).append("\"\r\n\r\n")
            head.append(v).append("\r\n")
        }
        head.append("--").append(boundary).append("\r\n")
        head.append("Content-Disposition: form-data; name=\"").append(fileField)
            .append("\"; filename=\"").append(file.name.replace("\"", "")).append("\"\r\n")
        head.append("Content-Type: ").append(mime).append("\r\n\r\n")
        val headBytes = head.toString().toByteArray(Charsets.UTF_8)
        val tailBytes = "\r\n--$boundary--\r\n".toByteArray(Charsets.UTF_8)

        val c = open(
            url,
            "POST",
            mapOf("Content-Type" to "multipart/form-data; boundary=$boundary"),
            UPLOAD_READ_MS,
        )
        c.doOutput = true
        c.setFixedLengthStreamingMode(headBytes.size.toLong() + file.length() + tailBytes.size.toLong())
        c.outputStream.use { out ->
            out.write(headBytes)
            file.inputStream().use { it.copyTo(out, 64 * 1024) }
            out.write(tailBytes)
        }
        return read(c)
    }
}

/** Guesses a MIME type from the file extension. */
fun mimeOf(path: String): String? = when (path.substringAfterLast('.', "").lowercase()) {
    "jpg", "jpeg" -> "image/jpeg"
    "png" -> "image/png"
    "gif" -> "image/gif"
    "webp" -> "image/webp"
    "mp4" -> "video/mp4"
    "m4v" -> "video/x-m4v"
    "mov" -> "video/quicktime"
    "webm" -> "video/webm"
    "avi" -> "video/x-msvideo"
    "mpeg", "mpg" -> "video/mpeg"
    "3gp" -> "video/3gpp"
    "mkv" -> "video/x-matroska"
    else -> null
}
