package com.abuploader.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abuploader.app.AdGroupRow
import com.abuploader.app.AdRow
import com.abuploader.app.Adsterra
import com.abuploader.app.SmartLink
import com.abuploader.app.Store
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.LocalDate

/** Everything the Adsterra screen shows, loaded in one go. */
private class AdsData(
    val perKey: Map<String, List<AdRow>>,
    val errors: Map<String, String>,
    val placements: List<AdGroupRow>,
    val domains: List<AdGroupRow>,
    val countries: List<AdGroupRow>,
    val links: List<SmartLink>,
)

private fun merge(target: MutableMap<String, AdGroupRow>, rows: List<AdGroupRow>) {
    for (r in rows) {
        val old = target[r.label]
        if (old == null) {
            target[r.label] = AdGroupRow(r.label, r.revenue, r.impressions)
        } else {
            old.revenue += r.revenue
            old.impressions += r.impressions
        }
    }
}

/** Blocking: call from a background thread. */
private fun loadAds(keys: List<String>, from: LocalDate, to: LocalDate): AdsData {
    val perKey = mutableMapOf<String, List<AdRow>>()
    val errors = mutableMapOf<String, String>()
    val placements = mutableMapOf<String, AdGroupRow>()
    val domains = mutableMapOf<String, AdGroupRow>()
    val countries = mutableMapOf<String, AdGroupRow>()
    val links = mutableListOf<SmartLink>()
    for (k in keys) {
        try {
            perKey[k] = Adsterra.daily(k, from, to)
        } catch (e: Exception) {
            errors[k] = e.message ?: e.toString()
            continue
        }
        // Extra breakdowns: a failure here only hides that card.
        var placementNames: Map<String, String> = emptyMap()
        var domainNames: Map<String, String> = emptyMap()
        try {
            val (names, l) = Adsterra.placements(k)
            placementNames = names
            links.addAll(l)
        } catch (_: Exception) {
        }
        try {
            domainNames = Adsterra.domains(k)
        } catch (_: Exception) {
        }
        try {
            merge(placements, Adsterra.grouped(k, from, to, "placement", placementNames))
        } catch (_: Exception) {
        }
        try {
            merge(domains, Adsterra.grouped(k, from, to, "domain", domainNames))
        } catch (_: Exception) {
        }
        try {
            merge(countries, Adsterra.grouped(k, from, to, "country", emptyMap()))
        } catch (_: Exception) {
        }
    }
    return AdsData(
        perKey,
        errors,
        placements.values.sortedByDescending { it.revenue },
        domains.values.sortedByDescending { it.revenue },
        countries.values.sortedByDescending { it.revenue },
        links.distinctBy { it.url },
    )
}

@Composable
fun AdsScreen() {
    Store.rev
    val keys = Store.settings.adsterraKeys
    var range by remember { mutableIntStateOf(2) } // 0 today, 1 yesterday, 2 7 days, 3 30 days
    var reload by remember { mutableIntStateOf(0) }
    var loading by remember { mutableStateOf(false) }
    var data by remember { mutableStateOf<AdsData?>(null) }
    var addOpen by remember { mutableStateOf(false) }
    var removeKey by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(keys, range, reload) {
        if (keys.isEmpty()) {
            data = null
            return@LaunchedEffect
        }
        loading = true
        val today = LocalDate.now()
        val (from, to) = when (range) {
            0 -> today to today
            1 -> today.minusDays(1) to today.minusDays(1)
            2 -> today.minusDays(6) to today
            else -> today.minusDays(29) to today
        }
        data = withContext(Dispatchers.IO) { loadAds(keys, from, to) }
        loading = false
    }

    SubScreen(
        "Adsterra earnings",
        guide = Guides.ADS,
        actions = {
            IconButton(onClick = { reload++ }) {
                Icon(Icons.Filled.Refresh, contentDescription = "Reload", tint = C.amber)
            }
        },
        fab = {
            ExtendedFloatingActionButton(
                onClick = { addOpen = true },
                icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                text = { Text("Add API key") },
                containerColor = C.orange,
                contentColor = Color.White,
            )
        },
    ) {
        if (keys.isEmpty()) {
            EmptyState(
                Icons.Filled.ShoppingCart,
                "No keys yet",
                "Tap \"Add API key\" and paste a read-only publisher API key from your Adsterra account (Adsterra > API). You can add several accounts.",
            )
        } else {
            Segmented(listOf("Today", "Yesterday", "7 days", "30 days"), range) { range = it }
            val d = data
            if (loading || d == null) {
                AppCard {
                    Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = androidx.compose.foundation.layout.Arrangement.Center) {
                        CircularProgressIndicator(color = C.orange)
                    }
                }
            } else {
                AdsBody(d)
            }
            SectionLabel("Accounts")
            keys.forEachIndexed { i, k ->
                AppCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Account ${i + 1}  ••••${k.takeLast(4)}", color = C.text, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                            val err = d?.errors?.get(k)
                            val rows = d?.perKey?.get(k)
                            if (err != null) {
                                Text(err, color = C.red, fontSize = 13.sp)
                            } else if (rows != null) {
                                Text(
                                    "${money(rows.sumOf { it.revenue })} · ${"%,d".format(rows.sumOf { it.impressions })} views",
                                    color = C.muted,
                                )
                            }
                        }
                        IconButton(onClick = { removeKey = k }) {
                            Icon(Icons.Filled.Delete, contentDescription = "Remove", tint = C.red)
                        }
                    }
                }
            }
        }
    }

    if (addOpen) {
        InputDialog("Adsterra publisher API key", "Paste key", onDismiss = { addOpen = false }) {
            addOpen = false
            if (it.isNotEmpty() && it !in keys) {
                Store.setAdsterraKeys(keys + it)
                AdsCache.day = ""
            }
        }
    }
    removeKey?.let { k ->
        ConfirmDialog("Remove this key?", "Its earnings are no longer shown.", "Remove", { removeKey = null }) {
            removeKey = null
            Store.setAdsterraKeys(keys.filter { it != k })
            AdsCache.day = ""
        }
    }
}

@Composable
private fun AdsBody(d: AdsData) {
    val all = d.perKey.values.flatten()
    val rev = all.sumOf { it.revenue }
    val imp = all.sumOf { it.impressions }
    val clk = all.sumOf { it.clicks }
    val cpm = if (imp == 0L) 0.0 else rev / imp * 1000
    val byDate = all.groupBy { it.date.take(10) }.mapValues { e -> e.value.sumOf { it.revenue } }.toSortedMap()

    AppCard {
        Text("Total earnings", color = C.muted, fontSize = 15.sp)
        Text(money(rev), color = C.text, fontSize = 38.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(10.dp))
        Row {
            Stat("Views", "%,d".format(imp), Modifier.weight(1f))
            Stat("Clicks", "%,d".format(clk), Modifier.weight(1f))
            Stat("CPM", money(cpm), Modifier.weight(1f))
        }
    }
    if (byDate.size > 1) {
        AppCard {
            Text("Daily revenue", color = C.text, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(8.dp))
            val values = byDate.values.toList()
            val max = (values.maxOrNull() ?: 0.0).coerceAtLeast(0.01)
            Canvas(
                Modifier
                    .fillMaxWidth()
                    .height(120.dp),
            ) {
                val slot = size.width / values.size
                val w = slot * 0.6f
                values.forEachIndexed { i, v ->
                    val h = (size.height * (v / max)).toFloat()
                    drawRoundRect(
                        color = C.card2,
                        topLeft = Offset(i * slot + (slot - w) / 2, 0f),
                        size = Size(w, size.height),
                        cornerRadius = CornerRadius(6f, 6f),
                    )
                    if (h > 0f) {
                        drawRoundRect(
                            color = C.amber,
                            topLeft = Offset(i * slot + (slot - w) / 2, size.height - h),
                            size = Size(w, h),
                            cornerRadius = CornerRadius(6f, 6f),
                        )
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            byDate.entries.reversed().forEach { (date, v) ->
                Row(Modifier.padding(vertical = 3.dp)) {
                    Text(date, color = C.text, modifier = Modifier.weight(1f))
                    Text(money(v), color = C.text, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
    TopCard("Top placements", d.placements)
    TopCard("Top websites", d.domains)
    TopCard("Top countries", d.countries)
    if (d.links.isNotEmpty()) SmartLinks(d.links)
}

@Composable
private fun Stat(label: String, value: String, modifier: Modifier) {
    Column(modifier) {
        Text(value, color = C.text, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold)
        Text(label, color = C.muted)
    }
}

@Composable
private fun TopCard(title: String, rows: List<AdGroupRow>) {
    if (rows.isEmpty()) return
    AppCard {
        Text(title, color = C.text, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(6.dp))
        rows.take(5).forEach { r ->
            Row(Modifier.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(r.label, color = C.text, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                Text("%,d views  ".format(r.impressions), color = C.muted, fontSize = 13.sp)
                Text(money(r.revenue), color = C.text, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun SmartLinks(links: List<SmartLink>) {
    val clip = LocalClipboardManager.current
    val ctx = LocalContext.current
    AppCard {
        Text("Smartlinks", color = C.text, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
        links.forEach { l ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(l.title, color = C.text, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(l.url, color = C.muted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                IconButton(onClick = {
                    clip.setText(AnnotatedString(l.url))
                    toast(ctx, "Link copied")
                }) {
                    Icon(Icons.Filled.Share, contentDescription = "Copy", tint = C.amber)
                }
            }
        }
    }
}
