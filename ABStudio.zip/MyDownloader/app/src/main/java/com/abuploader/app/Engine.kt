package com.abuploader.app

import android.content.Context
import android.os.PowerManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter

/** Publishes what is due. Runs on the main thread; network work goes to IO. */
object Engine {
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var busy = false
    private var lastSync = 0L
    private const val MISSED_MS = 2 * 3_600_000L
    private val hhmm = DateTimeFormatter.ofPattern("HH:mm")

    /** Runs one tick soon (safe to call often). */
    fun kick(ctx: Context) {
        val app = ctx.applicationContext
        scope.launch { tick(app) }
    }

    suspend fun tick(ctx: Context) {
        if (busy) return
        busy = true
        val pm = ctx.getSystemService(PowerManager::class.java)
        val lock = pm?.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ABUploader:engine")
        try {
            lock?.acquire(20 * 60_000L)
            Store.load(ctx)
            // New files in linked phone folders, checked every 10 minutes.
            if (System.currentTimeMillis() - lastSync > 10 * 60_000L) {
                lastSync = System.currentTimeMillis()
                try {
                    Store.syncLinked(ctx)
                } catch (_: Exception) {
                }
            }
            if (Store.settings.engineOn) Store.planDailyAutopilot()
            val now = System.currentTimeMillis()
            val due = Store.posts.filter { it.status == PostStatus.SCHEDULED && it.whenMs <= now }
            for (post in due) {
                if (post.status != PostStatus.SCHEDULED) continue
                val page = Store.pageById(post.pageId)
                if (now - post.whenMs > MISSED_MS) {
                    post.status = PostStatus.FAILED
                    post.error = "Missed: the engine was not running at that time"
                } else if (page == null) {
                    post.status = PostStatus.FAILED
                    post.error = "Page was removed"
                } else {
                    val titles = post.media.map { Store.titleOf(it) }
                    val temps = mutableListOf<java.io.File>()
                    try {
                        withContext(Dispatchers.IO) {
                            // Files from linked phone folders are copied to the cache for the upload.
                            val local = post.media.mapIndexed { i, m -> MediaFiles.localCopy(ctx, m, titles[i], temps) }
                            Publisher.publish(page, post.withMedia(local))
                        }
                        post.status = PostStatus.POSTED
                        post.error = null
                        // ✅ tick in AB Downloader's gallery and upload queue
                        post.media.forEach { Downloader.markPosted(ctx, it) }
                    } catch (e: Exception) {
                        post.status = PostStatus.FAILED
                        post.error = e.message ?: e.toString()
                    } finally {
                        temps.forEach { it.delete() }
                    }
                }
                Store.changed()
                Notif.postResult(ctx, page?.name ?: "a removed Page", post)
            }
            Notif.updateEngine(ctx, statusText())
            if (Store.settings.engineOn) Watchdog.schedule(ctx)
        } finally {
            busy = false
            try {
                if (lock?.isHeld == true) lock.release()
            } catch (_: Exception) {
            }
        }
    }

    fun statusText(): String {
        val today = LocalDate.now()
        val next = Store.nextDueMs()
        val nextText = if (next == null) {
            "nothing scheduled"
        } else {
            "next " + Instant.ofEpochMilli(next).atZone(ZoneId.systemDefault()).format(hhmm)
        }
        return "Posted today: ${Store.countOn(today)} · Failed: ${Store.countOn(today, PostStatus.FAILED)} · $nextText"
    }
}

/** Real Facebook or Zernio for connected Pages, simulated for demo Pages. Blocking. */
object Publisher {
    fun publish(page: PageAccount, post: ScheduledPost) {
        when {
            page.viaZernio -> Zernio.publish(page, post)
            page.viaFacebook -> Facebook.publish(page, post)
            else -> {
                Thread.sleep(600)
                if (post.media.isEmpty()) throw Exception("No media selected")
            }
        }
    }
}
