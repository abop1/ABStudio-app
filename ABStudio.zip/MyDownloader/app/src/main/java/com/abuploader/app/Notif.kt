package com.abuploader.app

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import com.abuploader.app.ui.UploaderActivity
import com.mydownloader.app.R

object Notif {
    const val ENGINE_ID = 4101
    private const val CH_ENGINE = "engine"
    private const val CH_POSTS = "posts"
    private var nextId = 5000

    fun ensureChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        nm.createNotificationChannel(
            NotificationChannel(CH_ENGINE, "Posting engine", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Keeps scheduled posting running"
                setShowBadge(false)
            },
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_POSTS, "Post results", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "Tells you when a post goes out or fails"
            },
        )
    }

    private fun openApp(ctx: Context): PendingIntent = PendingIntent.getActivity(
        ctx,
        1,
        Intent(ctx, UploaderActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    private fun allowed(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    fun engine(ctx: Context, text: String): Notification =
        Notification.Builder(ctx, CH_ENGINE)
            .setSmallIcon(R.drawable.ic_stat_upload)
            .setContentTitle("Pages: posting engine is running")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openApp(ctx))
            .build()

    fun updateEngine(ctx: Context, text: String) {
        if (!allowed(ctx) || !EngineService.running) return
        try {
            ctx.getSystemService(NotificationManager::class.java)?.notify(ENGINE_ID, engine(ctx, text))
        } catch (_: Exception) {
        }
    }

    fun postResult(ctx: Context, pageName: String, post: ScheduledPost) {
        if (!allowed(ctx)) return
        val ok = post.status == PostStatus.POSTED
        val title = if (ok) "Posted to $pageName" else "Failed on $pageName"
        val text = if (ok) post.type.label else "${post.type.label}: ${post.error ?: "unknown error"}"
        val n = Notification.Builder(ctx, CH_POSTS)
            .setSmallIcon(R.drawable.ic_stat_upload)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .setContentIntent(openApp(ctx))
            .build()
        try {
            ctx.getSystemService(NotificationManager::class.java)?.notify(nextId++, n)
        } catch (_: Exception) {
        }
    }
}
