package com.abuploader.app.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abuploader.app.Adsterra
import com.abuploader.app.PostStatus
import com.abuploader.app.ScheduledPost
import com.abuploader.app.Store
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter

/** Today's and yesterday's Adsterra earnings for the Home card (kept while the app runs). */
object AdsCache {
    var today: Double? = null
    var yesterday: Double? = null
    var day: String = ""
    var keys: List<String> = emptyList()
}

fun askBatteryExemption(ctx: Context) {
    try {
        val pm = ctx.getSystemService(PowerManager::class.java)
        if (pm != null && !pm.isIgnoringBatteryOptimizations(ctx.packageName)) {
            ctx.startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                    .setData(Uri.parse("package:" + ctx.packageName)),
            )
        }
    } catch (_: Exception) {
    }
}

private val timeFmt = DateTimeFormatter.ofPattern("d MMM, h:mm a")
fun fmtTime(ms: Long): String = Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()).format(timeFmt)
fun money(v: Double): String = "$" + String.format("%.2f", v)

@Composable
fun HomeScreen(onTab: (Int) -> Unit) {
    Store.rev
    val name = Store.settings.userName.substringBefore(' ')
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp),
    ) {
        ScreenTitle("Dashboard", hello = "Hi, $name", guide = Guides.HOME)
        AdsterraCard()
        EngineCard()
        StatGrid()
        SectionLabel("Last 14 days", "Analytics") { Nav.push(Route.Analytics) }
        AppCard { PostsChart() }
        if (Store.pages.isEmpty()) {
            AppCard {
                EmptyState(
                    icon = Icons.Filled.Share,
                    title = "Connect your first Page",
                    text = "Use a Facebook token or a Zernio API key.",
                    buttonLabel = "Open Connections",
                    onButton = { Nav.push(Route.Connections) },
                )
            }
        }
        SectionLabel("Up next", "Queue") { Nav.push(Route.Queue) }
        AppCard {
            val next = Store.upcoming.take(3)
            if (next.isEmpty()) {
                Text(
                    "Nothing scheduled. Turn on Pages and the engine, or schedule a post.",
                    color = C.muted,
                    fontSize = 15.sp,
                )
            } else {
                next.forEach { PostLine(it) }
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun AdsterraCard() {
    Store.rev
    val keys = Store.settings.adsterraKeys
    var today by remember { mutableStateOf(AdsCache.today) }
    var yesterday by remember { mutableStateOf(AdsCache.yesterday) }
    LaunchedEffect(keys) {
        val d = LocalDate.now()
        if (keys.isEmpty() || (AdsCache.day == d.toString() && AdsCache.keys == keys)) return@LaunchedEffect
        val result = withContext(Dispatchers.IO) {
            var t = 0.0
            var y = 0.0
            var any = false
            for (k in keys) {
                try {
                    for (r in Adsterra.daily(k, d.minusDays(1), d)) {
                        if (r.date.startsWith(d.toString())) t += r.revenue else y += r.revenue
                    }
                    any = true
                } catch (_: Exception) {
                }
            }
            if (any) t to y else null
        }
        if (result != null) {
            AdsCache.today = result.first
            AdsCache.yesterday = result.second
            AdsCache.day = d.toString()
            AdsCache.keys = keys
            today = result.first
            yesterday = result.second
        }
    }
    AppCard(onClick = { Nav.push(Route.Ads) }) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(54.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color.White),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Filled.ShoppingCart, contentDescription = null, tint = C.orange)
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text("Adsterra earnings", color = C.text, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold)
                val t = today
                val y = yesterday
                if (keys.isEmpty()) {
                    Text("Add your Adsterra API keys to see revenue and views.", color = C.muted)
                } else if (t == null || y == null) {
                    Text("Loading…", color = C.muted)
                } else {
                    Text("Today ${money(t)} · Yesterday ${money(y)}", color = C.amber, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

@Composable
private fun EngineCard() {
    Store.rev
    val ctx = LocalContext.current
    val on = Store.settings.engineOn
    AppCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(12.dp)
                    .clip(CircleShape)
                    .background(if (on) C.green else C.red),
            )
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("Posting engine", color = C.text, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold)
                Text(if (on) "Running, posts go out on time" else "Stopped", color = C.muted)
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(com.abuploader.app.Engine.statusText(), color = C.muted, fontSize = 14.sp)
        GradientButton(
            label = if (on) "Stop engine" else "Start engine",
            onClick = {
                Store.setEngine(ctx, !on)
                if (!on) askBatteryExemption(ctx)
            },
        )
        Text(
            "Phone has an Auto-start setting? Turn it on for AB Downloader.",
            color = C.muted,
            fontSize = 13.sp,
        )
    }
}

@Composable
private fun StatGrid() {
    Store.rev
    val stats = listOf(
        Triple("Pages on", "${Store.activePages.size}/${Store.pages.size}", C.amber),
        Triple("Followers", "%,d".format(Store.totalFollowers), C.blue),
        Triple("Posted", "${Store.postedCount}", C.green),
        Triple("Failed", "${Store.failedCount}", C.red),
    )
    stats.chunked(2).forEach { row ->
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            row.forEach { (label, value, color) ->
                AppCard(modifier = Modifier.weight(1f)) {
                    Text(value, color = color, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
                    Text(label, color = C.muted)
                }
            }
        }
    }
}

@Composable
fun PostsChart() {
    Store.rev
    val today = LocalDate.now()
    val days = (13 downTo 0).map { today.minusDays(it.toLong()) }
    val ok = days.map { Store.countOn(it) }
    val bad = days.map { Store.countOn(it, PostStatus.FAILED) }
    val max = (ok.zip(bad).maxOfOrNull { it.first + it.second } ?: 0).coerceAtLeast(1)
    Canvas(
        Modifier
            .fillMaxWidth()
            .height(130.dp),
    ) {
        val slot = size.width / days.size
        val barW = slot * 0.6f
        days.indices.forEach { i ->
            val x = i * slot + (slot - barW) / 2
            val hOk = size.height * ok[i] / max
            val hBad = size.height * bad[i] / max
            drawRoundRect(
                color = C.card2,
                topLeft = Offset(x, 0f),
                size = Size(barW, size.height),
                cornerRadius = CornerRadius(8f, 8f),
            )
            if (hOk > 0) {
                drawRoundRect(
                    color = C.orange,
                    topLeft = Offset(x, size.height - hOk),
                    size = Size(barW, hOk),
                    cornerRadius = CornerRadius(8f, 8f),
                )
            }
            if (hBad > 0) {
                drawRoundRect(
                    color = C.red,
                    topLeft = Offset(x, size.height - hOk - hBad),
                    size = Size(barW, hBad),
                    cornerRadius = CornerRadius(8f, 8f),
                )
            }
        }
    }
    Spacer(Modifier.height(6.dp))
    Row(Modifier.fillMaxWidth()) {
        Text(days.first().dayOfMonth.toString() + " " + days.first().month.name.take(3).lowercase(), color = C.muted, fontSize = 12.sp, modifier = Modifier.weight(1f))
        Text("■ posted  ", color = C.orange, fontSize = 12.sp)
        Text("■ failed", color = C.red, fontSize = 12.sp)
    }
}

@Composable
fun PostLine(p: ScheduledPost) {
    val page = Store.pageById(p.pageId)
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(page?.name ?: "Removed Page", color = C.text, fontWeight = FontWeight.SemiBold)
            Text("${p.type.label} · ${fmtTime(p.whenMs)}${if (p.auto) " · autopilot" else ""}", color = C.muted, fontSize = 13.sp)
        }
        when (p.status) {
            PostStatus.SCHEDULED -> Pill("Scheduled", C.amber)
            PostStatus.POSTED -> Pill("Posted", C.green)
            PostStatus.FAILED -> Pill("Failed", C.red)
        }
    }
}
