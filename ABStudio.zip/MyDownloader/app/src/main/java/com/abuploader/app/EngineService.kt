package com.abuploader.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/** Foreground service that keeps the posting engine alive with the app closed. */
class EngineService : Service() {
    private var loop: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Notif.ensureChannels(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Store.load(this)
        val n = Notif.engine(this, Engine.statusText())
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(Notif.ENGINE_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(Notif.ENGINE_ID, n)
            }
        } catch (e: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!Store.settings.engineOn) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        running = true
        Watchdog.schedule(this)
        if (loop?.isActive != true) {
            val app = applicationContext
            loop = Engine.scope.launch {
                while (isActive) {
                    Engine.tick(app)
                    delay(30_000)
                }
            }
        } else {
            Engine.kick(this)
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        loop?.cancel()
        super.onDestroy()
    }

    companion object {
        @Volatile
        var running = false
            private set

        fun start(ctx: Context) {
            try {
                ctx.startForegroundService(Intent(ctx, EngineService::class.java))
            } catch (_: Exception) {
                // Android may refuse a start from the background; the watchdog tries again.
            }
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, EngineService::class.java))
        }
    }
}

/** Wakes the phone at the next post time (or every 15 minutes) and restarts the engine if needed. */
object Watchdog {
    private const val MAX_WAIT = 15 * 60_000L

    private fun pending(ctx: Context): PendingIntent = PendingIntent.getBroadcast(
        ctx,
        7,
        Intent(ctx, WatchdogReceiver::class.java),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    fun schedule(ctx: Context) {
        val am = ctx.getSystemService(AlarmManager::class.java) ?: return
        val now = System.currentTimeMillis()
        var at = now + MAX_WAIT
        val next = Store.nextDueMs()
        if (next != null && next > now + 5_000 && next < at) at = next
        val pi = pending(ctx)
        try {
            if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            }
        } catch (_: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    fun cancel(ctx: Context) {
        ctx.getSystemService(AlarmManager::class.java)?.cancel(pending(ctx))
    }
}

class WatchdogReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Store.load(context)
        if (!Store.settings.engineOn) return
        Watchdog.schedule(context)
        EngineService.start(context)
        Engine.kick(context)
    }
}

/** Starts the engine again after a phone restart or an app update. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Store.load(context)
        if (!Store.settings.engineOn) return
        EngineService.start(context)
        Watchdog.schedule(context)
    }
}
