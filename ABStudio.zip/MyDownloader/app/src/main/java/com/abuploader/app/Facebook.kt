package com.abuploader.app

import org.json.JSONObject
import java.io.File

class FbException(message: String) : Exception(message)

/** The Facebook Graph API calls AB Uploader needs. Blocking: call from a background thread. */
object Facebook {
    private const val V = "v25.0"
    private const val GRAPH = "https://graph.facebook.com/$V"
    private const val GRAPH_VIDEO = "https://graph-video.facebook.com/$V"

    private fun decode(r: Http.Resp): JSONObject {
        val j = try {
            JSONObject(r.body)
        } catch (e: Exception) {
            throw FbException("Unexpected reply from Facebook (${r.code})")
        }
        val err = j.optJSONObject("error")
        if (err != null) throw FbException(err.optString("message", "Facebook error"))
        if (!r.ok) throw FbException("Facebook error ${r.code}")
        return j
    }

    private fun idOf(j: JSONObject): String =
        j.str("post_id") ?: j.str("id") ?: throw FbException("Facebook did not return an id")

    /** Turns a short-lived user token into a long-lived one. */
    fun extendToken(appId: String, appSecret: String, token: String): String {
        val url = Http.withQuery(
            "$GRAPH/oauth/access_token",
            mapOf(
                "grant_type" to "fb_exchange_token",
                "client_id" to appId,
                "client_secret" to appSecret,
                "fb_exchange_token" to token,
            ),
        )
        return decode(Http.get(url)).str("access_token")
            ?: throw FbException("Facebook did not return a long-lived token")
    }

    /** Every Page the user manages, each with its own Page token. */
    fun listPages(userToken: String): List<JSONObject> {
        val out = mutableListOf<JSONObject>()
        var url: String? = Http.withQuery(
            "$GRAPH/me/accounts",
            mapOf(
                "fields" to "id,name,access_token,followers_count,fan_count",
                "limit" to "100",
                "access_token" to userToken,
            ),
        )
        var guard = 0
        while (url != null && guard < 50) {
            val j = decode(Http.get(url))
            val data = j.optJSONArray("data")
            if (data != null) {
                for (i in 0 until data.length()) data.optJSONObject(i)?.let { out.add(it) }
            }
            url = j.optJSONObject("paging")?.str("next")
            guard++
        }
        return out
    }

    fun followers(pageId: String, token: String): Int {
        val url = Http.withQuery(
            "$GRAPH/$pageId",
            mapOf("fields" to "followers_count,fan_count", "access_token" to token),
        )
        val j = decode(Http.get(url))
        return if (j.has("followers_count")) j.optInt("followers_count") else j.optInt("fan_count")
    }

    fun photo(pageId: String, token: String, path: String, caption: String, published: Boolean = true): String {
        val f = File(path)
        val r = Http.multipart(
            "$GRAPH/$pageId/photos",
            mapOf(
                "access_token" to token,
                "caption" to caption,
                "published" to if (published) "true" else "false",
            ),
            "source",
            f,
            mimeOf(path) ?: "image/jpeg",
        )
        return idOf(decode(r))
    }

    /** Normal (non-Reel) video post on the Page timeline. */
    fun video(pageId: String, token: String, path: String, caption: String): String {
        val r = Http.multipart(
            "$GRAPH_VIDEO/$pageId/videos",
            mapOf("access_token" to token, "description" to caption),
            "source",
            File(path),
            mimeOf(path) ?: "video/mp4",
        )
        return idOf(decode(r))
    }

    /** One post with several photos. */
    fun photos(pageId: String, token: String, paths: List<String>, caption: String): String {
        val ids = paths.map { photo(pageId, token, it, "", published = false) }
        val body = mutableMapOf("message" to caption, "access_token" to token)
        ids.forEachIndexed { i, id ->
            body["attached_media[$i]"] = JSONObject().put("media_fbid", id).toString()
        }
        return idOf(decode(Http.postForm("$GRAPH/$pageId/feed", body)))
    }

    /** edge = video_reels or video_stories. Returns the video id. */
    private fun resumable(edge: String, pageId: String, token: String, path: String, caption: String): String {
        val base = "$GRAPH/$pageId/$edge"
        val start = decode(Http.postForm(base, mapOf("upload_phase" to "start", "access_token" to token)))
        val videoId = start.str("video_id") ?: throw FbException("Facebook did not start the upload")
        val uploadUrl = start.str("upload_url") ?: "https://rupload.facebook.com/video-upload/$V/$videoId"

        val f = File(path)
        val up = Http.sendFile(
            uploadUrl,
            "POST",
            f,
            mapOf(
                "Authorization" to "OAuth $token",
                "offset" to "0",
                "file_size" to f.length().toString(),
                "Content-Type" to "application/octet-stream",
            ),
        )
        decode(up)

        val finish = mutableMapOf(
            "upload_phase" to "finish",
            "video_id" to videoId,
            "access_token" to token,
        )
        if (edge == "video_reels") {
            finish["video_state"] = "PUBLISHED"
            finish["description"] = caption
        }
        decode(Http.postForm(base, finish))
        return videoId
    }

    fun reel(pageId: String, token: String, path: String, caption: String) =
        resumable("video_reels", pageId, token, path, caption)

    fun videoStory(pageId: String, token: String, path: String) =
        resumable("video_stories", pageId, token, path, "")

    fun photoStory(pageId: String, token: String, path: String): String {
        val photoId = photo(pageId, token, path, "", published = false)
        val j = decode(
            Http.postForm(
                "$GRAPH/$pageId/photo_stories",
                mapOf("photo_id" to photoId, "access_token" to token),
            ),
        )
        return j.str("post_id") ?: j.str("id") ?: photoId
    }

    fun comment(objectId: String, token: String, text: String) {
        decode(Http.postForm("$GRAPH/$objectId/comments", mapOf("message" to text, "access_token" to token)))
    }

    fun publish(page: PageAccount, post: ScheduledPost) {
        val token = page.token ?: throw FbException("Page is not connected to Facebook")
        val fbId = page.fbId ?: throw FbException("Page is not connected to Facebook")
        if (post.media.isEmpty()) throw FbException("No media selected")
        for (m in post.media) {
            if (!File(m).exists()) throw FbException("Media file not found on this phone")
        }
        val path = post.media.first()
        val id = when (post.type) {
            PostType.REEL -> reel(fbId, token, path, post.caption)
            PostType.VIDEO -> video(fbId, token, path, post.caption)
            PostType.IMAGE -> photo(fbId, token, path, post.caption)
            PostType.PHOTOS -> photos(fbId, token, post.media, post.caption)
            PostType.IMG_STORY -> photoStory(fbId, token, path)
            PostType.VIDEO_STORY -> videoStory(fbId, token, path)
        }
        val c = post.firstComment
        if (!c.isNullOrBlank() && !post.type.isStory) {
            try {
                comment(id, token, c)
            } catch (_: Exception) {
                // The post is already live; a failed first comment does not fail it.
            }
        }
    }
}
