package com.abuploader.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import kotlin.random.Random

/**
 * Single source of truth. Everything is saved on the phone (encrypted file).
 * Change data only on the main thread, then call [changed].
 */
object Store {
    private var file: File? = null
    private var loaded = false
    private var appCtx: Context? = null

    /** Screens read this so they redraw after every change. */
    var rev by mutableIntStateOf(0)
        private set

    var settings = Settings()
    val pages = mutableListOf<PageAccount>()
    val folders = mutableListOf<LibraryFolder>()
    val posts = mutableListOf<ScheduledPost>()
    var captionPool: List<String> = emptyList()
    var commentPool: List<String> = emptyList()
    private var lastPlannedDay = ""
    var connectLink: ConnectLink? = null
        private set

    private const val MAX_HISTORY = 500
    private const val HOUR = 3_600_000L

    // ---------- load / save ----------
    fun load(ctx: Context) {
        if (loaded) return
        loaded = true
        appCtx = ctx.applicationContext
        val f = File(ctx.applicationContext.filesDir, "state.json")
        file = f
        if (!f.exists()) return
        val raw = try {
            f.readText()
        } catch (e: Exception) {
            return
        }
        val text = Crypto.decrypt(raw)
        if (text == null) {
            // Keep the unreadable file instead of overwriting it.
            f.renameTo(File(f.parentFile, "state.unreadable"))
            return
        }
        try {
            val j = JSONObject(text)
            j.optJSONObject("settings")?.let { settings = Settings.fromJson(it) }
            fill(j.optJSONArray("pages")) { pages.add(PageAccount.fromJson(it)) }
            fill(j.optJSONArray("folders")) { folders.add(LibraryFolder.fromJson(it)) }
            fill(j.optJSONArray("posts")) { posts.add(ScheduledPost.fromJson(it)) }
            captionPool = j.optJSONArray("captions").strings()
            commentPool = j.optJSONArray("comments").strings()
            lastPlannedDay = j.optString("lastPlannedDay", "")
            connectLink = j.optJSONObject("connectLink")?.let { ConnectLink.fromJson(it) }
        } catch (_: Exception) {
        }
    }

    private fun fill(a: JSONArray?, add: (JSONObject) -> Unit) {
        if (a == null) return
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            try {
                add(o)
            } catch (_: Exception) {
            }
        }
    }

    fun save() {
        val f = file ?: return
        trimHistory()
        val j = JSONObject()
        j.put("settings", settings.toJson())
        j.put("pages", JSONArray().apply { pages.forEach { put(it.toJson()) } })
        j.put("folders", JSONArray().apply { folders.forEach { put(it.toJson()) } })
        j.put("posts", JSONArray().apply { posts.forEach { put(it.toJson()) } })
        j.put("captions", captionPool.toJsonArray())
        j.put("comments", commentPool.toJsonArray())
        j.put("lastPlannedDay", lastPlannedDay)
        connectLink?.let { j.put("connectLink", it.toJson()) }
        val plain = j.toString()
        val out = Crypto.encrypt(plain) ?: plain
        try {
            val tmp = File(f.parentFile, "state.tmp")
            tmp.writeText(out)
            if (!tmp.renameTo(f)) {
                f.writeText(out)
                tmp.delete()
            }
        } catch (_: Exception) {
        }
    }

    private fun trimHistory() {
        val done = posts.filter { it.status != PostStatus.SCHEDULED }
        if (done.size <= MAX_HISTORY) return
        val drop = done.sortedBy { it.whenMs }.take(done.size - MAX_HISTORY).map { it.id }.toSet()
        posts.removeAll { it.id in drop }
    }

    fun changed() {
        save()
        rev++
    }

    fun newId(): String = "${System.currentTimeMillis()}${Random.nextInt(10000)}"

    // ---------- derived numbers ----------
    val activePages: List<PageAccount> get() = pages.filter { it.active }
    val totalFollowers: Int get() = pages.sumOf { it.followers }
    val postedCount: Int get() = posts.count { it.status == PostStatus.POSTED }
    val failedCount: Int get() = posts.count { it.status == PostStatus.FAILED }
    val upcoming: List<ScheduledPost>
        get() = posts.filter { it.status == PostStatus.SCHEDULED }.sortedBy { it.whenMs }
    val history: List<ScheduledPost>
        get() = posts.filter { it.status != PostStatus.SCHEDULED }.sortedByDescending { it.whenMs }

    fun dayOf(ms: Long): LocalDate = Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()).toLocalDate()

    fun countOn(day: LocalDate, status: PostStatus = PostStatus.POSTED): Int =
        posts.count { it.status == status && dayOf(it.whenMs) == day }

    fun pageById(id: String): PageAccount? = pages.firstOrNull { it.id == id }
    fun folderById(id: String?): LibraryFolder? = if (id == null) null else folders.firstOrNull { it.id == id }
    fun foldersOfKind(kind: Int): List<LibraryFolder> = folders.filter { it.kind == kind }

    // ---------- pages ----------
    fun addPage(name: String) {
        pages.add(PageAccount(id = newId(), name = name))
        changed()
    }

    /** Imports every Page the token manages. Returns how many were found. */
    suspend fun connectFacebook(userToken: String, appId: String, appSecret: String): Int {
        val found = withContext(Dispatchers.IO) {
            var token = userToken.trim()
            if (appId.isNotBlank() && appSecret.isNotBlank()) {
                token = Facebook.extendToken(appId.trim(), appSecret.trim(), token)
            }
            Facebook.listPages(token)
        }
        for (f in found) {
            val fbId = f.optString("id")
            val name = f.str("name") ?: "Page"
            val pageToken = f.str("access_token")
            val followers = if (f.has("followers_count")) f.optInt("followers_count") else f.optInt("fan_count")
            val existing = pages.firstOrNull { it.fbId == fbId && !it.viaZernio }
            if (existing != null) {
                existing.name = name
                existing.token = pageToken
                existing.followers = followers
                existing.source = "facebook"
            } else {
                pages.add(
                    PageAccount(
                        id = newId(),
                        name = name,
                        source = "facebook",
                        followers = followers,
                        fbId = fbId,
                        token = pageToken,
                    ),
                )
            }
        }
        changed()
        return found.size
    }

    // ---------- Zernio ----------
    fun zernioKey(key: String): ZernioKey? = settings.zernioKeys.firstOrNull { it.key == key }
    val zernioChannelsLeft: Int get() = settings.zernioKeys.sumOf { it.left }

    /** Saves a Zernio key and imports every Facebook Page it can post to. Returns the Page count. */
    suspend fun connectZernio(key: String, name: String): Int {
        val k = key.trim()
        val scan = withContext(Dispatchers.IO) { Zernio.scan(k) }
        val existing = zernioKey(k)
        if (existing == null) {
            val label = name.trim().ifEmpty { "Key ${settings.zernioKeys.size + 1}" }
            settings.zernioKeys = settings.zernioKeys + ZernioKey(k, label, used = scan.channelsUsed)
        } else {
            existing.used = scan.channelsUsed
            if (name.isNotBlank()) existing.name = name.trim()
        }
        mergeZernio(k, scan.pages)
        changed()
        return scan.pages.size
    }

    /** Reads the Zernio keys again: new Pages appear, channel counts update. Returns failures. */
    suspend fun refreshZernio(only: String? = null): Int {
        var failed = 0
        for (zk in settings.zernioKeys.filter { only == null || it.key == only }) {
            val scan = try {
                withContext(Dispatchers.IO) { Zernio.scan(zk.key) }
            } catch (e: Exception) {
                failed++
                null
            } ?: continue
            zk.used = scan.channelsUsed
            mergeZernio(zk.key, scan.pages)
        }
        changed()
        return failed
    }

    fun setPermanentLink(url: String) {
        settings.permanentLink = url.trim().trimEnd('/')
        changed()
    }

    /** Text for the Cloudflare ZERNIO_KEYS secret: key:limit for every key. */
    fun zernioKeysForWorker(): String = settings.zernioKeys.joinToString(",") { "${it.key}:${it.limit}" }

    fun setZernioLimit(key: String, limit: Int) {
        zernioKey(key)?.limit = limit.coerceIn(1, 999)
        changed()
    }

    /** Makes a connect link through a key that still has a free channel (valid 30 minutes). */
    suspend fun createConnectLink(): ConnectLink {
        if (settings.zernioKeys.isEmpty()) throw ZernioException("Add a Zernio API key first.")
        refreshZernio()
        val zk = settings.zernioKeys.firstOrNull { it.left > 0 }
            ?: throw ZernioException("Every key is full. Add another Zernio key or raise a key's limit.")
        val result = withContext(Dispatchers.IO) {
            val pid = zk.profileId ?: Zernio.defaultProfileId(zk.key)
            pid to Zernio.connectLink(zk.key, pid)
        }
        zk.profileId = result.first
        val link = ConnectLink(result.second, zk.key, System.currentTimeMillis(), zk.used)
        connectLink = link
        changed()
        return link
    }

    /** How many channels were added to the link's key since the link was made. */
    fun connectLinkConnected(): Int {
        val l = connectLink ?: return 0
        val zk = zernioKey(l.key) ?: return 0
        return (zk.used - l.baseUsed).coerceAtLeast(0)
    }

    private fun mergeZernio(key: String, found: List<ZernioPage>) {
        for (f in found) {
            val existing = pages.firstOrNull { it.zernioAccountId == f.accountId && it.fbId == f.pageId }
            if (existing != null) {
                existing.name = f.name
                existing.zernioKey = key
                existing.followers = f.followers
            } else {
                pages.add(
                    PageAccount(
                        id = newId(),
                        name = f.name,
                        source = "zernio",
                        followers = f.followers,
                        fbId = f.pageId,
                        zernioKey = key,
                        zernioAccountId = f.accountId,
                    ),
                )
            }
        }
    }

    /** Removes a Zernio key and the Pages imported with it. */
    fun removeZernioKey(key: String) {
        settings.zernioKeys = settings.zernioKeys.filter { it.key != key }
        if (connectLink?.key == key) connectLink = null
        val gone = pages.filter { it.zernioKey == key }.map { it.id }.toSet()
        pages.removeAll { it.id in gone }
        posts.removeAll { it.pageId in gone && it.status == PostStatus.SCHEDULED }
        changed()
    }

    fun zernioPageCount(key: String): Int = pages.count { it.zernioKey == key }

    /** Reads the current follower count of every connected Page. */
    suspend fun refreshFollowers(): Int {
        var n = 0
        val fbPages = pages.filter { it.viaFacebook }.map { Triple(it, it.fbId!!, it.token!!) }
        val counts = withContext(Dispatchers.IO) {
            fbPages.map { (p, id, token) ->
                p to try {
                    Facebook.followers(id, token)
                } catch (e: Exception) {
                    null
                }
            }
        }
        for ((p, c) in counts) {
            if (c != null) {
                p.followers = c
                n++
            }
        }
        for (zk in settings.zernioKeys) {
            val scan = try {
                withContext(Dispatchers.IO) { Zernio.scan(zk.key) }
            } catch (e: Exception) {
                null
            } ?: continue
            zk.used = scan.channelsUsed
            mergeZernio(zk.key, scan.pages)
            n += scan.pages.size
        }
        changed()
        return n
    }

    fun removePage(id: String) {
        pages.removeAll { it.id == id }
        posts.removeAll { it.pageId == id && it.status == PostStatus.SCHEDULED }
        changed()
    }

    fun setAllPages(on: Boolean) {
        pages.forEach { it.active = on }
        replan()
    }

    fun setPageActive(page: PageAccount, on: Boolean) {
        page.active = on
        replan()
    }

    // ---------- library ----------
    val topFolders: List<LibraryFolder> get() = folders.filter { it.parentId == null || folderById(it.parentId) == null }
    fun children(id: String): List<LibraryFolder> = folders.filter { it.parentId == id }

    /** "asmrfruit / Reels" style name. */
    fun folderPath(f: LibraryFolder): String {
        val parent = folderById(f.parentId)
        return if (parent == null) f.name else "${folderPath(parent)} / ${f.name}"
    }

    /** All files in a folder and its sub-folders. */
    fun allFiles(f: LibraryFolder): List<MediaFile> {
        val out = f.files.toMutableList()
        children(f.id).forEach { out.addAll(allFiles(it)) }
        return out
    }

    fun pagesUsing(folderId: String): Int =
        pages.count { p -> (0..2).any { p.folderIdFor(it) == folderId } }

    val totalFiles: Int get() = folders.sumOf { it.files.size }

    fun addFolder(name: String, kind: Int, parentId: String? = null): LibraryFolder {
        val f = LibraryFolder(id = newId(), name = name, kind = kind, parentId = parentId)
        folders.add(f)
        changed()
        return f
    }

    fun renameFolder(id: String, name: String) {
        folderById(id)?.name = name
        changed()
    }

    /** Deletes a folder, its sub-folders and the copies of their files. */
    fun removeFolder(id: String) {
        val ids = mutableSetOf<String>()
        fun collect(fid: String) {
            ids.add(fid)
            children(fid).forEach { collect(it.id) }
        }
        collect(id)
        folders.filter { it.id in ids }.forEach { f -> f.files.forEach { MediaFiles.delete(it.path) } }
        folders.removeAll { it.id in ids }
        for (p in pages) {
            if (p.reelsFolderId in ids) p.reelsFolderId = null
            if (p.imagesFolderId in ids) p.imagesFolderId = null
            if (p.storiesFolderId in ids) p.storiesFolderId = null
        }
        changed()
    }

    fun addFiles(folderId: String, files: List<MediaFile>) {
        val f = folderById(folderId) ?: return
        for (m in files) if (f.files.none { it.path == m.path }) f.files.add(m)
        changed()
    }

    fun removeFile(folderId: String, m: MediaFile) {
        folderById(folderId)?.files?.removeAll { it.path == m.path }
        MediaFiles.delete(m.path)
        changed()
    }

    /**
     * Gives every Page a main folder with its name and Images, Reels and Stories sub-folders,
     * and links them to the Page. Existing links are kept. Returns how many folders were made.
     */
    fun createFolderSet(): Int {
        var made = 0
        for (p in pages) {
            val missing = (0..2).filter { folderById(p.folderIdFor(it)) == null }
            if (missing.isEmpty()) continue
            val parent = folders.firstOrNull {
                it.parentId == null && it.kind == FolderKind.GENERAL && it.name == p.name
            } ?: LibraryFolder(id = newId(), name = p.name, kind = FolderKind.GENERAL).also {
                folders.add(it)
                made++
            }
            for (kind in listOf(FolderKind.IMAGES, FolderKind.REELS, FolderKind.STORIES)) {
                if (kind !in missing) continue
                val existing = folders.firstOrNull { it.parentId == parent.id && it.kind == kind }
                val f = existing ?: LibraryFolder(
                    id = newId(),
                    name = FolderKind.names[kind],
                    kind = kind,
                    parentId = parent.id,
                ).also {
                    folders.add(it)
                    made++
                }
                p.setFolderFor(kind, f.id)
            }
        }
        changed()
        return made
    }

    fun linkFolder(id: String, treeUri: String, name: String) {
        val f = folderById(id) ?: return
        f.linkedUri = treeUri
        f.linkedName = name
        changed()
    }

    /** Stops following the phone folder; files that came from it are removed from the list. */
    fun unlinkFolder(id: String) {
        val f = folderById(id) ?: return
        f.linkedUri = null
        f.linkedName = null
        f.files.removeAll { it.linked }
        changed()
    }

    /**
     * Reads linked phone folders again: new files are added, deleted ones removed.
     * Returns how many new files were found.
     */
    suspend fun syncLinked(ctx: Context, onlyId: String? = null): Int {
        val targets = folders.filter { it.linkedUri != null && (onlyId == null || it.id == onlyId) }
            .map { it.id to it.linkedUri!! }
        if (targets.isEmpty()) return 0
        val app = ctx.applicationContext
        val results = withContext(Dispatchers.IO) {
            targets.map { (id, uri) ->
                id to try {
                    if (Downloader.isLink(uri)) {
                        Downloader.list(Downloader.dirOf(uri))
                    } else {
                        MediaFiles.listTree(app, android.net.Uri.parse(uri))
                    }
                } catch (e: Exception) {
                    null
                }
            }
        }
        var added = 0
        for ((id, list) in results) {
            val f = folderById(id) ?: continue
            if (list == null) continue
            val now = list.map { it.path }.toSet()
            f.files.removeAll { it.linked && it.path !in now }
            for (m in list) {
                if (f.files.none { it.path == m.path }) {
                    f.files.add(m)
                    added++
                }
            }
            if (f.files.isNotEmpty()) f.cursor %= f.files.size else f.cursor = 0
        }
        changed()
        return added
    }

    /** The title of a library file (for linked files the original name). */
    fun titleOf(path: String): String? {
        for (f in folders) for (m in f.files) if (m.path == path) return m.title
        return null
    }

    // ---------- caption / comment pools ----------
    fun setPools(captions: List<String>, comments: List<String>) {
        captionPool = captions
        commentPool = comments
        changed()
    }

    private fun pick(l: List<String>): String = if (l.isEmpty()) "" else l[Random.nextInt(l.size)]

    // ---------- manual posting ----------
    /** Queues one post per Page. Caption mode: Random, Use & remove, One for all. */
    fun queuePosts(
        targets: List<PageAccount>,
        type: PostType,
        media: List<String>,
        captions: List<String>,
        captionMode: String,
        comments: List<String>,
        whenMs: Long,
    ): Int {
        val pool = captions.toMutableList()
        for (page in targets) {
            val cap = when {
                pool.isEmpty() -> ""
                captionMode == "Use & remove" -> pool.removeAt(0)
                captionMode == "One for all" -> pool.first()
                else -> pool[Random.nextInt(pool.size)]
            }
            val finalCap = if (cap.isEmpty() && !type.isStory && media.size == 1) downloaderCaption(media[0]) ?: "" else cap
            val comment = if (comments.isEmpty() || type.isStory) null else pick(comments)
            posts.add(
                ScheduledPost(
                    id = newId(),
                    pageId = page.id,
                    type = type,
                    media = media,
                    caption = finalCap,
                    whenMs = whenMs,
                    firstComment = comment,
                ),
            )
        }
        changed()
        return targets.size
    }

    fun cancelPost(id: String) {
        posts.removeAll { it.id == id }
        changed()
    }

    fun retryFailed(): Int {
        val now = System.currentTimeMillis()
        var n = 0
        for (p in posts) {
            if (p.status == PostStatus.FAILED) {
                p.status = PostStatus.SCHEDULED
                p.error = null
                p.whenMs = now
                n++
            }
        }
        changed()
        return n
    }

    fun clearHistory() {
        posts.removeAll { it.status != PostStatus.SCHEDULED }
        changed()
    }

    // ---------- settings ----------
    fun setUserName(name: String) {
        settings.userName = name
        changed()
    }

    fun setAdsterraKeys(keys: List<String>) {
        settings.adsterraKeys = keys
        changed()
    }

    fun setUseOriginalCaption(on: Boolean) {
        settings.useOriginalCaption = on
        changed()
    }

    /** The original caption of an AB Downloader video, when that option is on. */
    fun downloaderCaption(path: String): String? {
        val ctx = appCtx ?: return null
        if (!settings.useOriginalCaption) return null
        return Downloader.caption(ctx, path)
    }

    fun setAutopilot(startHour: Int, endHour: Int, autoFirstComment: Boolean) {
        settings.startHour = startHour
        settings.endHour = endHour
        settings.autoFirstComment = autoFirstComment
        replan()
    }

    fun setEngine(ctx: Context, on: Boolean) {
        settings.engineOn = on
        if (on) {
            planDailyAutopilot()
            EngineService.start(ctx)
        } else {
            EngineService.stop(ctx)
            Watchdog.cancel(ctx)
        }
        changed()
    }

    // ---------- daily autopilot ----------
    /** Removes today's unsent autopilot posts and plans them again. */
    fun replan() {
        posts.removeAll { it.auto && it.status == PostStatus.SCHEDULED }
        lastPlannedDay = ""
        if (settings.engineOn) planDailyAutopilot()
        changed()
    }

    private fun slots(page: PageAccount, count: Int, fixed: Boolean, now: Long): List<Long> {
        val today = LocalDate.now()
        val zone = ZoneId.systemDefault()
        val out = mutableListOf<Long>()
        if (fixed && page.fixedTimes.isNotEmpty()) {
            for (s in page.fixedTimes) {
                val parts = s.split(":")
                if (parts.size != 2) continue
                val h = parts[0].toIntOrNull() ?: continue
                val m = parts[1].toIntOrNull() ?: continue
                if (h !in 0..23 || m !in 0..59) continue
                out.add(today.atTime(h, m).atZone(zone).toInstant().toEpochMilli())
            }
        } else if (count > 0) {
            val startH = settings.startHour.coerceIn(0, 23)
            val endH = if (settings.endHour > startH) settings.endHour.coerceAtMost(24) else startH + 1
            val stepMs = (endH - startH) * HOUR / count
            val start = today.atStartOfDay(zone).toInstant().toEpochMilli() + startH * HOUR
            for (i in 0 until count) out.add(start + stepMs * i)
        }
        return out.filter { it >= now }
    }

    /** Plans today's autopilot posts once per day. */
    fun planDailyAutopilot() {
        val key = LocalDate.now().toString()
        if (lastPlannedDay == key) return
        lastPlannedDay = key
        val now = System.currentTimeMillis()
        // Files already planned or posted by AB Uploader are not picked again from creator folders.
        val planned = posts.filter { it.status != PostStatus.FAILED }.flatMap { it.media }.toMutableSet()
        for (page in activePages) {
            // regular posts alternate between the Reels and Images folders
            val regular = listOf(FolderKind.REELS, FolderKind.IMAGES)
                .mapNotNull { folderById(page.folderIdFor(it)) }
                .filter { it.files.isNotEmpty() }
            if (regular.isNotEmpty()) {
                val times = slots(page, page.postsPerDay.coerceIn(0, 48), page.useFixedTimes, now)
                times.forEachIndexed { i, t ->
                    val file = pickFrom(regular[i % regular.size], planned)
                    if (file != null) addAuto(page, file, t, story = false)
                }
            }
            val storyFolder = folderById(page.storiesFolderId)
            if (storyFolder != null && storyFolder.files.isNotEmpty()) {
                for (t in slots(page, page.storiesPerDay.coerceIn(0, 48), false, now)) {
                    val file = pickFrom(storyFolder, planned) ?: continue
                    addAuto(page, file, t, story = true)
                }
            }
        }
        changed()
    }

    /**
     * Next file of a folder. Folders that follow an AB Downloader creator use its upload order
     * and never repeat a posted video; other folders go round in order.
     */
    private fun pickFrom(f: LibraryFolder, planned: MutableSet<String>): MediaFile? {
        val ctx = appCtx
        if (ctx != null && Downloader.isLink(f.linkedUri)) {
            val m = Downloader.next(ctx, f.files, planned) ?: return null
            planned.add(m.path)
            return m
        }
        return f.nextFile()
    }

    private fun addAuto(page: PageAccount, file: MediaFile, whenMs: Long, story: Boolean) {
        val type = if (story) {
            if (file.isVideo) PostType.VIDEO_STORY else PostType.IMG_STORY
        } else {
            if (file.isVideo) PostType.REEL else PostType.IMAGE
        }
        val comment = if (!story && settings.autoFirstComment && commentPool.isNotEmpty()) pick(commentPool) else null
        posts.add(
            ScheduledPost(
                id = newId(),
                pageId = page.id,
                type = type,
                media = listOf(file.path),
                caption = if (story) "" else downloaderCaption(file.path) ?: pick(captionPool),
                whenMs = whenMs,
                firstComment = comment,
                auto = true,
            ),
        )
    }

    /** Time of the next scheduled post, or null. */
    fun nextDueMs(): Long? = posts.filter { it.status == PostStatus.SCHEDULED }.minOfOrNull { it.whenMs }
}
