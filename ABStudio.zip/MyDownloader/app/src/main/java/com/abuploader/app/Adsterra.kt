package com.abuploader.app

import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

class AdRow(val date: String, val revenue: Double, val impressions: Long, val clicks: Long)

/** One line of a breakdown (a placement, a website or a country). */
class AdGroupRow(val label: String, var revenue: Double, var impressions: Long)

/** A placement with a direct url (a Smartlink). */
class SmartLink(val title: String, val url: String)

/** Adsterra publisher API, read-only key. Blocking: call from a background thread. */
object Adsterra {
    private const val BASE = "https://api3.adsterratools.com/publisher"

    private fun get(key: String, path: String, q: Map<String, String> = emptyMap()): Any {
        val r = Http.get(
            Http.withQuery("$BASE/$path", q),
            mapOf("X-API-Key" to key, "Accept" to "application/json"),
        )
        if (r.code == 401 || r.code == 403) throw Exception("The API key was refused. Check that it is correct.")
        if (r.code != 200) throw Exception("Adsterra replied with error ${r.code}.")
        val t = r.body.trim()
        return if (t.startsWith("[")) JSONArray(t) else JSONObject(t)
    }

    private fun items(j: Any): List<JSONObject> {
        val arr: JSONArray? = when (j) {
            is JSONArray -> j
            is JSONObject -> j.optJSONArray("items") ?: j.optJSONArray("data") ?: j.optJSONArray("stats")
            else -> null
        }
        val out = mutableListOf<JSONObject>()
        if (arr != null) for (i in 0 until arr.length()) arr.optJSONObject(i)?.let { out.add(it) }
        return out
    }

    private fun num(o: JSONObject, vararg keys: String): Double {
        for (k in keys) {
            if (!o.has(k) || o.isNull(k)) continue
            val v = o.opt(k)
            if (v is Number) return v.toDouble()
            v?.toString()?.toDoubleOrNull()?.let { return it }
        }
        return 0.0
    }

    private fun range(from: LocalDate, to: LocalDate) =
        mapOf("start_date" to from.toString(), "finish_date" to to.toString())

    fun daily(key: String, from: LocalDate, to: LocalDate): List<AdRow> =
        items(get(key, "stats.json", range(from, to) + ("group_by" to "date"))).map {
            AdRow(
                it.str("date") ?: it.str("day") ?: "",
                num(it, "revenue"),
                num(it, "impression", "impressions").toLong(),
                num(it, "clicks", "click").toLong(),
            )
        }

    /** group: placement, domain or country. [names] turns ids into readable titles. */
    fun grouped(
        key: String,
        from: LocalDate,
        to: LocalDate,
        group: String,
        names: Map<String, String>,
    ): List<AdGroupRow> =
        items(get(key, "stats.json", range(from, to) + ("group_by" to group))).map {
            val label = if (group == "country") {
                it.str("country") ?: it.str("country_code") ?: it.str("geo") ?: "?"
            } else {
                val id = it.str(group) ?: it.str("${group}_id") ?: ""
                it.str("${group}_name") ?: it.str("${group}_title") ?: names[id] ?: id.ifEmpty { "?" }
            }
            AdGroupRow(label, num(it, "revenue"), num(it, "impression", "impressions").toLong())
        }

    /** Website ids to names. */
    fun domains(key: String): Map<String, String> =
        items(get(key, "domains.json")).associate {
            it.optString("id") to (it.str("title") ?: it.str("name") ?: it.str("domain") ?: it.optString("id"))
        }

    /** Placement ids to names, plus every placement that has a direct url (Smartlinks). */
    fun placements(key: String): Pair<Map<String, String>, List<SmartLink>> {
        val names = mutableMapOf<String, String>()
        val links = mutableListOf<SmartLink>()
        for (e in items(get(key, "placements.json"))) {
            val title = e.str("title") ?: e.str("alias") ?: e.str("name") ?: e.optString("id")
            names[e.optString("id")] = title
            val url = e.str("direct_url") ?: e.str("directUrl") ?: e.str("url")
            if (url != null && url.startsWith("http")) links.add(SmartLink(title, url))
        }
        return names to links
    }
}
