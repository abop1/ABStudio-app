package com.abuploader.app.ui

import android.app.TimePickerDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBox
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abuploader.app.FolderKind
import com.abuploader.app.PageAccount
import com.abuploader.app.Store

@Composable
fun PagesScreen() {
    Store.rev
    var query by remember { mutableStateOf("") }
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp),
    ) {
        ScreenTitle("Pages", guide = Guides.PAGES)
        Text(
            "${Store.pages.size} Pages, ${Store.activePages.size} turned on. Turn a Page on to post to it.",
            color = C.muted,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlineButton("All on", { Store.setAllPages(true) }, Modifier.weight(1f), C.green)
            OutlineButton("All off", { Store.setAllPages(false) }, Modifier.weight(1f), C.red)
            OutlineButton("Connect", { Nav.push(Route.Connections) }, Modifier.weight(1f), C.amber)
        }
        if (Store.pages.size > 6) Field(query, { query = it }, "Search Pages")
        if (Store.pages.isEmpty()) {
            EmptyState(
                icon = Icons.Filled.AccountBox,
                title = "No Pages yet",
                text = "Connect with a Facebook token or a Zernio API key.",
                buttonLabel = "Open Connections",
                onButton = { Nav.push(Route.Connections) },
            )
        }
        val q = query.trim().lowercase()
        Store.pages.filter { q.isEmpty() || it.name.lowercase().contains(q) }.forEach { PageTile(it) }
        Spacer(Modifier.height(16.dp))
    }
}

fun planText(p: PageAccount): String {
    val posts = if (p.useFixedTimes && p.fixedTimes.isNotEmpty()) {
        "${p.fixedTimes.size} posts at fixed times"
    } else {
        "${p.postsPerDay} posts a day"
    }
    return "$posts, ${p.storiesPerDay} stories a day"
}

@Composable
private fun PageTile(page: PageAccount) {
    AppCard(onClick = { Nav.push(Route.PageEdit(page.id)) }) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(C.card2),
                contentAlignment = Alignment.Center,
            ) {
                Text(page.name.take(1).uppercase(), color = C.amber, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(page.name, color = C.text, fontSize = 17.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(planText(page), color = C.muted, fontSize = 13.sp)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    when {
                        page.viaZernio -> Pill("Zernio", C.blue)
                        page.viaFacebook -> Pill("Facebook", C.blue)
                        else -> Pill("Demo", C.muted)
                    }
                    Spacer(Modifier.width(6.dp))
                    Text("%,d followers".format(page.followers), color = C.muted, fontSize = 12.sp)
                }
            }
            Switch(
                checked = page.active,
                onCheckedChange = { Store.setPageActive(page, it) },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Color.White,
                    checkedTrackColor = C.orange,
                    uncheckedThumbColor = C.muted,
                    uncheckedTrackColor = C.card2,
                ),
            )
        }
    }
}

@Composable
fun PageEditScreen(id: String) {
    Store.rev
    val ctx = LocalContext.current
    val page = Store.pageById(id)
    if (page == null) {
        SubScreen("Page") { Text("This Page was removed.", color = C.muted) }
        return
    }
    var confirmRemove by remember { mutableStateOf(false) }
    SubScreen(page.name, guide = Guides.PAGES) {
        Text(page.connectionLabel, color = C.muted)
        SwitchRow("Post to this Page", page.active, { Store.setPageActive(page, it) })

        SectionLabel("Daily autopilot")
        AppCard {
            Stepper("Posts per day (max 48)", page.postsPerDay, {
                page.postsPerDay = it
                Store.replan()
            })
            Stepper("Stories per day (max 48)", page.storiesPerDay, {
                page.storiesPerDay = it
                Store.replan()
            })
            SwitchRow(
                "Post at fixed times",
                page.useFixedTimes,
                {
                    page.useFixedTimes = it
                    Store.replan()
                },
                subtitle = "Off: posts are spread evenly over your posting hours",
            )
            if (page.useFixedTimes) {
                page.fixedTimes.chunked(4).forEach { row ->
                    Row {
                        row.forEach { t ->
                            Chip("$t  ✕", false, {
                                page.fixedTimes.remove(t)
                                Store.replan()
                            })
                        }
                    }
                }
                OutlineButton("Add a time", {
                    TimePickerDialog(ctx, { _, h, m ->
                        val v = "%02d:%02d".format(h, m)
                        if (v !in page.fixedTimes) {
                            page.fixedTimes.add(v)
                            page.fixedTimes.sort()
                            Store.replan()
                        }
                    }, 9, 0, true).show()
                }, color = C.amber)
            }
        }

        SectionLabel("Folders")
        AppCard {
            Text("The engine takes the next file from these folders.", color = C.muted, fontSize = 14.sp)
            for (kind in 0..2) FolderPicker(page, kind)
        }

        SectionLabel("Page")
        OutlineButton("Remove this Page", { confirmRemove = true }, Modifier.fillMaxWidth(), C.red)
    }
    if (confirmRemove) {
        ConfirmDialog(
            title = "Remove ${page.name}?",
            text = "Its scheduled posts are removed too. Folders and files stay in the Library.",
            yes = "Remove",
            onDismiss = { confirmRemove = false },
            onYes = {
                confirmRemove = false
                Nav.pop()
                Store.removePage(page.id)
            },
        )
    }
}

@Composable
private fun FolderPicker(page: PageAccount, kind: Int) {
    var open by remember { mutableStateOf(false) }
    val current = Store.folderById(page.folderIdFor(kind))
    // Folders of this kind first, then every other folder.
    val options = Store.folders.sortedWith(compareBy({ it.kind != kind }, { Store.folderPath(it).lowercase() }))
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(FolderKind.names[kind], color = C.text, fontSize = 16.sp, modifier = Modifier.width(80.dp))
        Box(Modifier.weight(1f)) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(androidx.compose.foundation.shape.RoundedCornerShape(14.dp))
                    .background(C.card2)
                    .clickable { open = true }
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    current?.let { "${Store.folderPath(it)} (${it.files.size})" } ?: "None",
                    color = if (current == null) C.muted else C.text,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f),
                )
                Icon(Icons.Filled.ArrowDropDown, contentDescription = null, tint = C.muted)
            }
            DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                DropdownMenuItem(text = { Text("None") }, onClick = {
                    open = false
                    page.setFolderFor(kind, null)
                    Store.replan()
                })
                options.forEach { f ->
                    DropdownMenuItem(text = { Text("${FolderKind.emojis[f.kind.coerceIn(0, 3)]} ${Store.folderPath(f)} (${f.files.size})") }, onClick = {
                        open = false
                        page.setFolderFor(kind, f.id)
                        Store.replan()
                    })
                }
                if (options.isEmpty()) {
                    DropdownMenuItem(text = { Text("No folders yet: Library > Page folder set", color = C.muted) }, onClick = {
                        open = false
                    })
                }
            }
        }
    }
}
