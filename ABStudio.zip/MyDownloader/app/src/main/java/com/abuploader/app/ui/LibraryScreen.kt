package com.abuploader.app.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abuploader.app.Downloader
import com.abuploader.app.FolderKind
import com.abuploader.app.LibraryFolder
import com.abuploader.app.MediaFiles
import com.abuploader.app.Store
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Yellow emoji tile like AlcashGo's folder icons. */
@Composable
fun EmojiTile(emoji: String) {
    Box(
        Modifier
            .size(48.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(C.amber.copy(alpha = 0.16f)),
        contentAlignment = Alignment.Center,
    ) {
        Text(emoji, fontSize = 22.sp)
    }
}

fun folderLine(f: LibraryFolder): String {
    val all = Store.allFiles(f)
    val parts = mutableListOf("${all.count { it.isVideo }} videos", "${all.count { !it.isVideo }} images")
    val subs = Store.children(f.id).size
    if (subs > 0) parts.add("$subs sub-folders")
    val pages = Store.pagesUsing(f.id)
    if (pages > 0) parts.add("on $pages Pages")
    if (f.linkedUri != null) parts.add("linked")
    return parts.joinToString(" · ")
}

@Composable
fun FolderRow(f: LibraryFolder) {
    AppCard(onClick = { Nav.push(Route.Folder(f.id)) }) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            EmojiTile(FolderKind.emojis[f.kind.coerceIn(0, 3)])
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(f.name, color = C.text, fontSize = 17.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(folderLine(f), color = C.muted, fontSize = 13.sp)
            }
            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null, tint = C.muted)
        }
    }
}

@Composable
fun LibraryScreen() {
    Store.rev
    val ctx = LocalContext.current
    var newOpen by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { Store.syncLinked(ctx) }
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp),
    ) {
        ScreenTitle("Library", guide = Guides.LIBRARY)
        AppCard {
            Text(
                "${Store.totalFiles} files in ${Store.folders.size} folders",
                color = C.text,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
            )
            Text(
                "Files stay on your phone. AB Uploader only remembers where they are and uploads them when a post goes out.",
                color = C.muted,
                fontSize = 14.sp,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                GradientButton(
                    label = "Page folder set",
                    icon = Icons.Filled.Star,
                    modifier = Modifier.weight(1f),
                    onClick = {
                        if (Store.pages.isEmpty()) {
                            toast(ctx, "Add a Page first")
                        } else {
                            val n = Store.createFolderSet()
                            toast(ctx, if (n == 0) "Every Page already has its folders" else "$n folder(s) created")
                        }
                    },
                )
                OutlineButton("+ Folder", { newOpen = true }, Modifier.weight(1f).padding(vertical = 3.dp))
            }
        }
        if (Store.folders.isEmpty()) {
            EmptyState(
                icon = Icons.Filled.Add,
                title = "No folders yet",
                text = "Tap \"Page folder set\" to give every Page its Images, Reels and Stories folders.",
            )
        }
        Store.topFolders.forEach { FolderRow(it) }
        Spacer(Modifier.height(16.dp))
    }
    if (newOpen) {
        FolderDialog("New folder", "", FolderKind.GENERAL, onDismiss = { newOpen = false }) { name, kind ->
            newOpen = false
            Store.addFolder(name, kind)
        }
    }
}

/** Name + type dialog for new folders and sub-folders. */
@Composable
fun FolderDialog(
    title: String,
    initialName: String,
    initialKind: Int,
    onDismiss: () -> Unit,
    onOk: (String, Int) -> Unit,
) {
    var name by remember { mutableStateOf(initialName) }
    var kind by remember { mutableIntStateOf(initialKind) }
    // shown order: Folder, Images, Reels, Stories
    val order = listOf(FolderKind.GENERAL, FolderKind.IMAGES, FolderKind.REELS, FolderKind.STORIES)
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = { if (name.isNotBlank()) onOk(name.trim(), kind) }, enabled = name.isNotBlank()) {
                Text("Create")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
        title = { Text(title) },
        text = {
            Column {
                Field(name, { name = it }, "Folder name")
                Segmented(order.map { FolderKind.names[it] }, order.indexOf(kind).coerceAtLeast(0)) { kind = order[it] }
            }
        },
        containerColor = C.card,
    )
}

@Composable
fun FolderScreen(id: String) {
    Store.rev
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val folder = Store.folderById(id)
    var copying by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }
    var subOpen by remember { mutableStateOf(false) }
    var renameOpen by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var creatorOpen by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris: List<Uri> ->
        if (uris.isEmpty() || folder == null) return@rememberLauncherForActivityResult
        copying = true
        scope.launch {
            var failed = 0
            val kept = withContext(Dispatchers.IO) {
                uris.mapNotNull {
                    try {
                        MediaFiles.keep(ctx, it)
                    } catch (e: Exception) {
                        failed++
                        null
                    }
                }
            }
            Store.addFiles(folder.id, kept)
            copying = false
            toast(ctx, "${kept.size} file(s) added" + if (failed > 0) ", $failed could not be read" else "")
        }
    }
    val treePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        if (uri == null || folder == null) return@rememberLauncherForActivityResult
        try {
            ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) {
        }
        Store.linkFolder(folder.id, uri.toString(), MediaFiles.treeName(uri))
        scope.launch {
            val n = Store.syncLinked(ctx, folder.id)
            toast(ctx, "Phone folder linked, $n file(s) found")
        }
    }

    LaunchedEffect(id) {
        if (folder?.linkedUri != null) Store.syncLinked(ctx, id)
    }

    if (folder == null) {
        SubScreen("Folder") { Text("This folder was removed.", color = C.muted) }
        return
    }
    SubScreen(
        folder.name,
        actions = {
            Box {
                IconButton(onClick = { menuOpen = true }) {
                    Icon(Icons.Filled.MoreVert, contentDescription = "Menu", tint = C.text)
                }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    DropdownMenuItem(
                        text = { Text("New sub-folder") },
                        leadingIcon = { Icon(Icons.Filled.Add, contentDescription = null) },
                        onClick = {
                            menuOpen = false
                            subOpen = true
                        },
                    )
                    DropdownMenuItem(
                        text = { Text(if (folder.linkedUri == null) "Link a phone folder" else "Unlink phone folder") },
                        leadingIcon = { Icon(Icons.Filled.Phone, contentDescription = null) },
                        onClick = {
                            menuOpen = false
                            if (folder.linkedUri == null) {
                                try {
                                    treePicker.launch(null)
                                } catch (_: Exception) {
                                    toast(ctx, "This phone cannot pick folders")
                                }
                            } else {
                                Store.unlinkFolder(folder.id)
                            }
                        },
                    )
                    if (folder.linkedUri == null) {
                        DropdownMenuItem(
                            text = { Text("Link AB Downloader creator") },
                            leadingIcon = { Icon(Icons.Filled.Refresh, contentDescription = null) },
                            onClick = {
                                menuOpen = false
                                creatorOpen = true
                            },
                        )
                    }
                    DropdownMenuItem(
                        text = { Text("Rename") },
                        leadingIcon = { Icon(Icons.Filled.Edit, contentDescription = null) },
                        onClick = {
                            menuOpen = false
                            renameOpen = true
                        },
                    )
                    DropdownMenuItem(
                        text = { Text("Delete folder", color = C.red) },
                        leadingIcon = { Icon(Icons.Filled.Delete, contentDescription = null, tint = C.red) },
                        onClick = {
                            menuOpen = false
                            confirmDelete = true
                        },
                    )
                }
            }
        },
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            GradientButton(
                label = if (copying) "Copying…" else "Add from phone",
                icon = Icons.Filled.Add,
                modifier = Modifier.weight(1f),
                enabled = !copying,
                onClick = { picker.launch(arrayOf("image/*", "video/*")) },
            )
            OutlineButton("+ Sub-folder", { subOpen = true }, Modifier.weight(1f).padding(vertical = 3.dp))
        }

        Store.children(folder.id).forEach { FolderRow(it) }

        val linked = folder.linkedUri
        if (linked != null) {
            AppCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Phone, contentDescription = null, tint = C.amber)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            if (Downloader.isLink(linked)) "Linked AB Downloader creator" else "Linked phone folder",
                            color = C.text,
                            fontWeight = FontWeight.Bold,
                        )
                        Text(folder.linkedName ?: "Phone folder", color = C.muted, fontSize = 13.sp)
                    }
                    IconButton(onClick = {
                        scope.launch {
                            val n = Store.syncLinked(ctx, folder.id)
                            toast(ctx, if (n == 0) "No new files" else "$n new file(s)")
                        }
                    }) {
                        Icon(Icons.Filled.Refresh, contentDescription = "Check for new files", tint = C.amber)
                    }
                }
                Text(
                    if (Downloader.isLink(linked)) {
                        "New downloads of this creator appear here automatically. Autopilot posts each video once, " +
                            "series in order (Part 1, 2, 3…), the Reels version when there is one, and gives it the ✅ tick in Gallery."
                    } else {
                        "New videos and images you put in this phone folder appear here automatically."
                    },
                    color = C.muted,
                    fontSize = 13.sp,
                )
            }
        }

        val pages = Store.pagesUsing(folder.id)
        Text(
            "${folder.files.size} FILES" + if (pages > 0) " · USED BY $pages PAGE(S)" else "",
            color = C.muted,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(top = 16.dp, bottom = 4.dp),
        )
        if (folder.files.isEmpty()) {
            Text(
                "Add videos or images from your phone, or link a phone folder so new files appear automatically.",
                color = C.muted,
                fontSize = 14.sp,
            )
        }
        folder.files.forEachIndexed { i, m ->
            AppCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("${i + 1}.", color = C.muted, modifier = Modifier.width(34.dp))
                    Column(Modifier.weight(1f)) {
                        Text(m.name, color = C.text, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            (if (m.isVideo) "Video" else "Image") + if (m.linked) " · from phone folder" else "",
                            color = C.muted,
                            fontSize = 13.sp,
                        )
                    }
                    if (!m.linked) {
                        IconButton(onClick = { Store.removeFile(folder.id, m) }) {
                            Icon(Icons.Filled.Delete, contentDescription = "Remove", tint = C.red)
                        }
                    }
                }
            }
        }
    }

    if (creatorOpen) {
        CreatorPickerDialog(onDismiss = { creatorOpen = false }) { c ->
            creatorOpen = false
            Store.linkFolder(folder.id, Downloader.PREFIX + c.dir.absolutePath, "AB Downloader · " + c.name)
            scope.launch {
                val n = Store.syncLinked(ctx, folder.id)
                toast(ctx, "${c.name} linked, $n file(s) found")
            }
        }
    }
    if (subOpen) {
        FolderDialog("New sub-folder", "", FolderKind.REELS, onDismiss = { subOpen = false }) { name, kind ->
            subOpen = false
            Store.addFolder(name, kind, folder.id)
        }
    }
    if (renameOpen) {
        InputDialog("Rename folder", "Folder name", folder.name, onDismiss = { renameOpen = false }) {
            renameOpen = false
            if (it.isNotEmpty()) Store.renameFolder(folder.id, it)
        }
    }
    if (confirmDelete) {
        ConfirmDialog(
            title = "Delete ${folder.name}?",
            text = "The folder, its sub-folders and AB Uploader's copies of their files are deleted. " +
                "Your originals in the gallery and in linked phone folders stay.",
            yes = "Delete",
            onDismiss = { confirmDelete = false },
            onYes = {
                confirmDelete = false
                Nav.pop()
                Store.removeFolder(folder.id)
            },
        )
    }
}

@Composable
private fun CreatorPickerDialog(onDismiss: () -> Unit, onPick: (Downloader.CreatorFolder) -> Unit) {
    val ctx = LocalContext.current
    val creators = remember { Downloader.creators(ctx) }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
        title = { Text("AB Downloader creators") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                if (creators.isEmpty()) {
                    Text("No creators yet. Add creators in the Creators tab of AB Downloader.", color = C.muted)
                }
                creators.forEach { c ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { onPick(c) }
                            .padding(vertical = 12.dp, horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text("👤", fontSize = 18.sp)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(c.name, color = C.text, fontWeight = FontWeight.Bold)
                            Text(c.dir.name, color = C.muted, fontSize = 12.sp)
                        }
                    }
                }
            }
        },
        containerColor = C.card,
    )
}
