package com.abuploader.app.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abuploader.app.Store

/** One-time setup of a permanent connect link on a free Cloudflare Worker. */
@Composable
fun PermanentLinkScreen() {
    Store.rev
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    var url by remember { mutableStateOf(Store.settings.permanentLink) }

    fun copy(text: String, what: String) {
        clip.setText(AnnotatedString(text))
        toast(ctx, "$what copied")
    }

    SubScreen("Permanent link") {
        Text(
            "A Zernio link from the app works for 30 minutes. For a link that always works, like AlcashGo's, " +
                "put this small free page on Cloudflare once. Each time someone opens it, it picks a Zernio key " +
                "that still has a free channel and sends them to Facebook. The Facebook account logged in on " +
                "their phone or browser is used, and they pick the Page.",
            color = C.muted,
            lineHeight = 22.sp,
        )
        SectionLabel("Setup (one time, about 5 minutes)")
        AppCard {
            Step(1, "Open dash.cloudflare.com in a browser and sign up for free (or log in).")
            Step(2, "Go to Workers & Pages → Create → Create Worker (Hello World). Give it a name, for example ab-connect, and tap Deploy.")
            Step(3, "Tap Edit code, delete all the code there, paste the code from the button below and tap Deploy.")
            OutlineButton("Copy worker code", { copy(WORKER_CODE, "Worker code") }, color = C.amber)
            Step(4, "Open the Worker → Settings → Variables and Secrets → Add. Type: Secret, Name: ZERNIO_KEYS, Value: paste from the button below. Save and deploy.")
            OutlineButton("Copy my Zernio keys", {
                if (Store.settings.zernioKeys.isEmpty()) toast(ctx, "Add a Zernio key first") else copy(Store.zernioKeysForWorker(), "Keys")
            }, color = C.amber)
            Step(5, "Optional: add a Text variable OWNER_NAME with your name (${Store.settings.userName}). It shows on the page.")
            Step(6, "Copy the Worker address (like https://ab-connect.yourname.workers.dev) and paste it below.")
        }
        Field(url, { url = it }, "Worker address (https://….workers.dev)")
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            GradientButton(
                label = "Save",
                icon = Icons.Filled.Check,
                modifier = Modifier.weight(1f),
                onClick = {
                    val u = url.trim()
                    if (u.isNotEmpty() && !u.startsWith("https://")) {
                        toast(ctx, "The address must start with https://")
                    } else {
                        Store.setPermanentLink(u)
                        toast(ctx, if (u.isEmpty()) "Permanent link removed" else "Permanent link saved")
                        Nav.pop()
                    }
                },
            )
            OutlineButton("Test", {
                val u = url.trim()
                if (u.startsWith("https://")) {
                    try {
                        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)))
                    } catch (_: Exception) {
                    }
                } else {
                    toast(ctx, "Paste the Worker address first")
                }
            }, Modifier.weight(1f))
        }
        Spacer(Modifier.height(6.dp))
        Text(
            "Important: when you add a new Zernio key or change a key's limit, copy your keys again and update " +
                "ZERNIO_KEYS in Cloudflare. Keep the Worker private: anyone who has the link can connect a Page to your Zernio keys.",
            color = C.muted,
            fontSize = 13.sp,
            lineHeight = 19.sp,
        )
    }
}

@Composable
private fun Step(n: Int, text: String) {
    Row(Modifier.padding(vertical = 6.dp), verticalAlignment = Alignment.Top) {
        Box(
            Modifier
                .size(26.dp)
                .clip(CircleShape)
                .background(C.orange),
            contentAlignment = Alignment.Center,
        ) {
            Text("$n", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(12.dp))
        Text(text, color = C.text, fontSize = 14.sp, lineHeight = 20.sp, modifier = Modifier.weight(1f))
    }
}

/** Cloudflare Worker script (worker.js). Keep it free of dollar signs: this is a Kotlin raw string. */
const val WORKER_CODE = """// AB Uploader: permanent connect link (Cloudflare Worker, free plan is enough).
// Settings > Variables and Secrets:
//   ZERNIO_KEYS  (Secret)  keys with their channel limit, e.g.  sk_aaa:2,sk_bbb:2
//   OWNER_NAME   (Text, optional)  your name, shown on the page
const API = "https://zernio.com/api/v1";

const CSS =
  "body{margin:0;min-height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;" +
  "background:#0A0F1E;color:#F2F4FA;font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;padding:20px;box-sizing:border-box}" +
  ".card{max-width:420px;width:100%;background:#131A2B;border:1px solid #232C45;border-radius:22px;padding:28px;text-align:center;box-sizing:border-box}" +
  ".logo{width:64px;height:64px;border-radius:18px;background:#1877F2;color:#fff;font:700 38px/64px system-ui;margin:0 auto 16px}" +
  "h1{font-size:22px;margin:0 0 10px}p{color:#9AA3BC;line-height:1.5}" +
  ".btn{display:block;margin:22px 0 8px;padding:15px;border-radius:16px;background:linear-gradient(90deg,#FFC233,#FF7A00);" +
  "color:#fff;font-weight:700;text-decoration:none;font-size:17px}.ok{color:#22C55E}.bad{color:#EF6B6B}" +
  ".foot{color:#9AA3BC;font-size:12px;margin-top:16px}";

function esc(s) {
  return String(s).replace(/[&<>"']/g, function (c) {
    return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
  });
}

function page(title, body) {
  const html =
    "<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>" +
    "<title>" + esc(title) + "</title><style>" + CSS + "</style></head><body><div class='card'>" + body +
    "</div><p class='foot'>AB Uploader</p></body></html>";
  return new Response(html, { headers: { "content-type": "text/html; charset=utf-8", "cache-control": "no-store" } });
}

function parseKeys(raw) {
  return String(raw || "")
    .split(/[\s,;]+/)
    .filter(Boolean)
    .map(function (e) {
      const i = e.lastIndexOf(":");
      if (i > 0) {
        const n = parseInt(e.slice(i + 1), 10);
        if (String(n) === e.slice(i + 1)) return { key: e.slice(0, i), limit: n };
      }
      return { key: e, limit: 2 };
    });
}

async function api(key, path) {
  const r = await fetch(API + path, { headers: { Authorization: "Bearer " + key, Accept: "application/json" } });
  const text = await r.text();
  let j = null;
  try { j = JSON.parse(text); } catch (e) { j = null; }
  if (!r.ok) {
    const err = j && j.error ? (j.error.message || j.error) : "Zernio error " + r.status;
    throw new Error(String(err));
  }
  return j;
}

function list(j, names) {
  if (Array.isArray(j)) return j;
  for (const n of names) if (j && Array.isArray(j[n])) return j[n];
  return [];
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const home = url.origin + url.pathname;
    const owner = env.OWNER_NAME ? " to <b>" + esc(env.OWNER_NAME) + "</b>'s AB Uploader" : " to AB Uploader";

    if (url.searchParams.has("error")) {
      return page("Not connected",
        "<div class='logo'>f</div><h1 class='bad'>Not connected</h1><p>" +
        esc(url.searchParams.get("error_message") || url.searchParams.get("error")) +
        "</p><a class='btn' href='" + esc(home) + "'>Try again</a>");
    }
    if (url.searchParams.has("connected")) {
      return page("Page connected",
        "<div class='logo'>f</div><h1 class='ok'>Page connected ✓</h1><p><b>" +
        esc(url.searchParams.get("username") || "Your Page") + "</b> is now connected. You can close this page.</p>");
    }
    if (!url.searchParams.has("go")) {
      return page("Connect your Facebook Page",
        "<div class='logo'>f</div><h1>Connect your Facebook Page</h1><p>This connects one Facebook Page" + owner +
        ", so posts can be published to it.</p><a class='btn' href='?go=1'>Continue with Facebook</a>" +
        "<p>You choose the Page on the next screen. Each link use connects one Page.</p>");
    }

    const keys = parseKeys(env.ZERNIO_KEYS);
    if (!keys.length) {
      return page("Not set up", "<h1 class='bad'>Link not set up</h1><p>The owner has not added ZERNIO_KEYS yet.</p>");
    }
    for (const k of keys) {
      try {
        const accounts = list(await api(k.key, "/accounts"), ["accounts", "data"])
          .filter(function (a) { return a.enabled !== false; });
        if (accounts.length >= k.limit) continue; // this key is full, try the next one
        const profiles = list(await api(k.key, "/profiles"), ["profiles", "data"]);
        const p = profiles.find(function (x) { return x.isDefault; }) || profiles[0];
        if (!p) continue;
        const q = "?profileId=" + encodeURIComponent(p._id || p.id) +
          "&scopes=posting,comments,analytics&redirect_url=" + encodeURIComponent(home);
        const c = await api(k.key, "/connect/facebook" + q);
        if (c && c.authUrl) return Response.redirect(c.authUrl, 302);
      } catch (e) {
        // a broken key should not block the others
      }
    }
    return page("No free channel",
      "<div class='logo'>f</div><h1 class='bad'>No free channel left</h1>" +
      "<p>Ask the owner to add another Zernio key, then open this link again.</p>");
  },
};
"""
