package com.abuploader.app.ui

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abuploader.app.Engine
import com.abuploader.app.FolderKind
import com.abuploader.app.MediaFile
import com.abuploader.app.MediaFiles
import com.abuploader.app.PostType
import com.abuploader.app.Store
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDateTime
import java.time.ZoneId

@Composable
fun PostScreen() {
    Store.rev
    var mode by rememberSaveable { mutableIntStateOf(0) }
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp),
    ) {
        LaunchedEffect(PostDraft.version) { if (PostDraft.version > 0) mode = 0 }
        ScreenTitle("Post", guide = Guides.POST)
        Segmented(listOf("Schedule a post", "Bulk Daily"), mode) { mode = it }
        if (mode == 0) SinglePost() else BulkDaily()
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun SinglePost() {
    Store.rev
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var type by rememberSaveable { mutableStateOf(PostType.REEL) }
    val media = remember { mutableStateListOf<String>() }
    var captions by rememberSaveable { mutableStateOf("") }
    var captionMode by rememberSaveable { mutableIntStateOf(0) }
    var comments by rememberSaveable { mutableStateOf("") }
    var later by rememberSaveable { mutableStateOf(false) }
    var whenMs by rememberSaveable { mutableLongStateOf(System.currentTimeMillis() + 3_600_000L) }
    var copying by remember { mutableStateOf(false) }
    var libraryOpen by remember { mutableStateOf(false) }
    val modes = listOf("Random", "Use & remove", "One for all")

    // A video shared from AB Downloader (or another app) arrives with its caption.
    LaunchedEffect(PostDraft.version) {
        val d = PostDraft.take() ?: return@LaunchedEffect
        media.clear()
        media.addAll(if (d.third) d.first.take(1) else d.first.take(10))
        type = when {
            d.third -> PostType.REEL
            d.first.size > 1 -> PostType.PHOTOS
            else -> PostType.IMAGE
        }
        captions = d.second
        captionMode = 2
        later = false
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris: List<Uri> ->
        if (uris.isEmpty()) return@rememberLauncherForActivityResult
        copying = true
        scope.launch {
            try {
                val kept = withContext(Dispatchers.IO) {
                    val list = if (type.isMulti) uris.take(10) else uris.take(1)
                    list.map { MediaFiles.keep(ctx, it) }
                }
                if (!type.isMulti) media.clear()
                kept.forEach { if (it.path !in media) media.add(it.path) }
            } catch (e: Exception) {
                toast(ctx, "Could not read the file: ${e.message}")
            } finally {
                copying = false
            }
        }
    }

    SectionLabel("Type")
    PostType.entries.chunked(3).forEach { row ->
        Row(Modifier.fillMaxWidth()) {
            row.forEach { t ->
                Chip(t.label, t == type, {
                    if (t.needsVideo != type.needsVideo) media.clear()
                    if (!t.isMulti && media.size > 1) {
                        val first = media.first()
                        media.clear()
                        media.add(first)
                    }
                    type = t
                }, Modifier.weight(1f))
            }
        }
    }

    SectionLabel("Media")
    AppCard {
        if (media.isEmpty()) {
            Text(
                if (type.needsVideo) "Choose one video." else if (type.isMulti) "Choose 2 to 10 photos." else "Choose one photo.",
                color = C.muted,
            )
        }
        media.forEach { path ->
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 3.dp)) {
                Text(Store.titleOf(path) ?: path.substringAfterLast('/').substringAfter('_'), color = C.text, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                Text("✕", color = C.red, modifier = Modifier.clickable { media.remove(path) }.padding(8.dp))
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlineButton(if (copying) "Copying…" else "From phone", {
                if (!copying) picker.launch(arrayOf(if (type.needsVideo) "video/*" else "image/*"))
            }, Modifier.weight(1f), C.amber)
            OutlineButton("From Library", { libraryOpen = true }, Modifier.weight(1f), C.amber)
        }
    }

    if (!type.isStory) {
        SectionLabel("Captions")
        Field(captions, { captions = it }, "One or more captions (empty line between them)", minLines = 3, maxLines = 8)
        Segmented(modes, captionMode) { captionMode = it }
        SectionLabel("First comment")
        Field(comments, { comments = it }, "Optional, several = rotate (empty line between)", minLines = 2, maxLines = 6)
    } else {
        Text("Stories have no caption or comment.", color = C.muted, modifier = Modifier.padding(top = 10.dp))
    }

    SectionLabel("When")
    Segmented(listOf("Post now", "Schedule"), if (later) 1 else 0) { later = it == 1 }
    if (later) {
        OutlineButton(fmtTime(whenMs), {
            val zone = ZoneId.systemDefault()
            val cur = java.time.Instant.ofEpochMilli(whenMs).atZone(zone).toLocalDateTime()
            DatePickerDialog(ctx, { _, y, mo, d ->
                TimePickerDialog(ctx, { _, h, mi ->
                    whenMs = LocalDateTime.of(y, mo + 1, d, h, mi).atZone(zone).toInstant().toEpochMilli()
                }, cur.hour, cur.minute, true).show()
            }, cur.year, cur.monthValue - 1, cur.dayOfMonth).show()
        }, Modifier.fillMaxWidth(), C.amber)
    }

    val targets = Store.activePages
    Text(
        "Goes to ${targets.size} Page(s) turned on in the Pages tab.",
        color = C.muted,
        modifier = Modifier.padding(top = 8.dp),
    )
    GradientButton(
        label = if (later) "Schedule" else "Post now",
        icon = if (later) Icons.Filled.DateRange else Icons.AutoMirrored.Filled.Send,
        onClick = {
            when {
                targets.isEmpty() -> toast(ctx, "Turn on at least one Page in the Pages tab.")
                media.isEmpty() -> toast(ctx, "Choose a media file first.")
                type.isMulti && media.size < 2 -> toast(ctx, "Multi photo needs at least 2 photos.")
                later && whenMs < System.currentTimeMillis() -> toast(ctx, "Pick a time in the future.")
                else -> {
                    val n = Store.queuePosts(
                        targets = targets,
                        type = type,
                        media = media.toList(),
                        captions = if (type.isStory) emptyList() else splitBlocks(captions),
                        captionMode = modes[captionMode],
                        comments = if (type.isStory) emptyList() else splitBlocks(comments),
                        whenMs = if (later) whenMs else System.currentTimeMillis(),
                    )
                    toast(ctx, if (later) "$n post(s) scheduled" else "Posting to $n Page(s)…")
                    if (!later) Engine.kick(ctx)
                    media.clear()
                }
            }
        },
    )

    if (libraryOpen) {
        LibraryPickerDialog(
            videos = type.needsVideo,
            multi = type.isMulti,
            onDismiss = { libraryOpen = false },
            onPick = { picked ->
                libraryOpen = false
                if (!type.isMulti) media.clear()
                picked.forEach { if (it !in media) media.add(it) }
            },
        )
    }
}

@Composable
private fun LibraryPickerDialog(
    videos: Boolean,
    multi: Boolean,
    onDismiss: () -> Unit,
    onPick: (List<String>) -> Unit,
) {
    val files: List<MediaFile> = Store.folders.flatMap { it.files }.filter { it.isVideo == videos }.distinctBy { it.path }
    val chosen = remember { mutableStateListOf<String>() }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = { onPick(chosen.toList()) }, enabled = chosen.isNotEmpty()) { Text("Use") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
        title = { Text(if (videos) "Videos in your Library" else "Photos in your Library") },
        text = {
            Column(
                Modifier
                    .heightIn(max = 420.dp)
                    .verticalScroll(rememberScrollState()),
            ) {
                if (files.isEmpty()) Text("Nothing here yet. Add files in the Library tab.", color = C.muted)
                files.forEach { f ->
                    val sel = f.path in chosen
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable {
                                if (sel) {
                                    chosen.remove(f.path)
                                } else {
                                    if (!multi) chosen.clear()
                                    if (chosen.size < 10) chosen.add(f.path)
                                }
                            }
                            .padding(vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            f.name,
                            color = C.text,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f),
                        )
                        if (sel) Icon(Icons.Filled.Check, contentDescription = null, tint = C.orange)
                    }
                }
            }
        },
        containerColor = C.card,
    )
}

@Composable
private fun BulkDaily() {
    Store.rev
    val ctx = LocalContext.current
    var posts by rememberSaveable { mutableIntStateOf(3) }
    var stories by rememberSaveable { mutableIntStateOf(0) }
    var fixed by rememberSaveable { mutableStateOf(false) }
    val times = remember { mutableStateListOf<String>() }
    var captions by rememberSaveable { mutableStateOf(Store.captionPool.joinToString("\n\n")) }
    var comments by rememberSaveable { mutableStateOf(Store.commentPool.joinToString("\n\n")) }
    val targets = Store.activePages

    Text(
        "One daily plan for every Page that is turned on. Each Page posts from its own folders " +
            "(Library > Page folder set). Then start the engine on Home.",
        color = C.muted,
        modifier = Modifier.padding(top = 8.dp),
    )
    AppCard {
        Stepper("Posts per day", posts, { posts = it })
        Stepper("Stories per day", stories, { stories = it })
    }
    Segmented(listOf("Spread evenly", "Fixed times"), if (fixed) 1 else 0) { fixed = it == 1 }
    if (fixed) {
        AppCard {
            if (times.isEmpty()) Text("No times yet.", color = C.muted)
            times.chunked(4).forEach { row ->
                Row { row.forEach { t -> Chip("$t  ✕", false, { times.remove(t) }) } }
            }
            OutlineButton("Add a time", {
                TimePickerDialog(ctx, { _, h, m ->
                    val v = "%02d:%02d".format(h, m)
                    if (v !in times) {
                        times.add(v)
                        times.sort()
                    }
                }, 9, 0, true).show()
            }, color = C.amber)
        }
    }
    SectionLabel("Caption pool")
    Field(captions, { captions = it }, "Captions, empty line between them", minLines = 3, maxLines = 8)
    SectionLabel("First comment pool")
    Field(comments, { comments = it }, "Comments, empty line between them", minLines = 2, maxLines = 6)
    Text(
        "First comments are added when \"Auto first comment\" is on (More > Autopilot settings).",
        color = C.muted,
        fontSize = 13.sp,
    )
    Spacer(Modifier.height(6.dp))
    GradientButton(
        label = "Apply to ${targets.size} Page(s)",
        icon = Icons.Filled.Check,
        onClick = {
            when {
                targets.isEmpty() -> toast(ctx, "Turn on at least one Page in the Pages tab.")
                fixed && times.isEmpty() -> toast(ctx, "Add at least one fixed time.")
                else -> {
                    for (p in targets) {
                        p.postsPerDay = posts
                        p.storiesPerDay = stories
                        p.useFixedTimes = fixed
                        if (fixed) p.fixedTimes = times.toMutableList()
                    }
                    val noFolders = targets.count { p -> (0..2).all { Store.folderById(p.folderIdFor(it)) == null } }
                    Store.setPools(splitBlocks(captions), splitBlocks(comments))
                    Store.replan()
                    toast(
                        ctx,
                        if (noFolders > 0) {
                            "Plan saved. $noFolders Page(s) have no folders yet: Library > Page folder set."
                        } else {
                            "Plan saved for ${targets.size} Page(s)"
                        },
                    )
                }
            }
        },
    )
    Text(
        "Folder kinds: ${FolderKind.names.joinToString(", ")}. Reels and Images folders take turns for regular posts.",
        color = C.muted,
        fontSize = 13.sp,
        fontWeight = FontWeight.Normal,
    )
}
