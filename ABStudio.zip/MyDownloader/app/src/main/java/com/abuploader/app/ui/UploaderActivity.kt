package com.abuploader.app.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.AccountBox
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.fragment.app.FragmentActivity
import com.abuploader.app.MediaFiles
import com.mydownloader.app.AppLock
import com.mydownloader.app.LockScreen
import com.mydownloader.app.Themes
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.abuploader.app.Engine
import com.abuploader.app.EngineService
import com.abuploader.app.Notif
import com.abuploader.app.Store

/** Screens opened on top of the tabs. */
sealed interface Route {
    data object Connections : Route
    data object FacebookConnect : Route
    data object ZernioConnect : Route
    data object Settings : Route
    data object Queue : Route
    data object Analytics : Route
    data object Ads : Route
    data object Background : Route
    data object Guides : Route
    data object PermanentLink : Route
    data class PageEdit(val id: String) : Route
    data class Folder(val id: String) : Route
}

object Nav {
    val stack = mutableStateListOf<Route>()
    var tab by mutableIntStateOf(0)

    fun push(r: Route) {
        stack.add(r)
    }

    fun pop() {
        if (stack.isNotEmpty()) stack.removeAt(stack.size - 1)
    }
}

/** A post prepared from outside (AB Downloader's share, or any app's Share → Pages par post). */
object PostDraft {
    var version by mutableIntStateOf(0)
        private set
    private var media: List<String> = emptyList()
    private var caption: String = ""
    private var video: Boolean = true

    fun set(paths: List<String>, text: String, isVideo: Boolean) {
        media = paths
        caption = text
        video = isVideo
        version++
    }

    /** Returns the draft once (media, caption, isVideo), then forgets it. */
    fun take(): Triple<List<String>, String, Boolean>? {
        if (media.isEmpty()) return null
        val d = Triple(media, caption, video)
        media = emptyList()
        caption = ""
        return d
    }
}

/** The Pages part (AB Uploader) inside AB Downloader. */
class UploaderActivity : FragmentActivity() {
    private val locked = mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT < 26) {
            toast(this, "Pages ke liye Android 8 ya naya phone chahiye")
            finish()
            return
        }
        Themes.load(this)
        Store.load(this)
        Notif.ensureChannels(this)
        // Opened from inside AB Downloader (already unlocked) needs no second fingerprint.
        val fromApp = intent?.getBooleanExtra("from_abd", false) == true || intent?.hasExtra("ab_path") == true
        locked.value = savedInstanceState == null && AppLock.enabled(this) && !fromApp
        handleIntent(intent)
        setContent {
            AppTheme {
                Box(Modifier.fillMaxSize()) {
                    Root()
                    if (locked.value) {
                        LockScreen {
                            AppLock.prompt(this@UploaderActivity, "AB Uploader kholein", onOk = { locked.value = false })
                        }
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        if (Store.settings.engineOn) EngineService.start(this)
        Engine.kick(this)
    }

    /** Share → "Pages par post": fills the Post screen with the video and its caption. */
    private fun handleIntent(i: Intent?) {
        if (i == null) return
        val text = i.getStringExtra(Intent.EXTRA_TEXT) ?: ""
        val direct = i.getStringExtra("ab_path")
        if (direct != null) {
            showDraft(listOf(direct), text, MediaFiles.isVideoPath(direct))
            return
        }
        val uris: List<Uri> = when (i.action) {
            Intent.ACTION_SEND -> listOfNotNull(streamOf(i))
            Intent.ACTION_SEND_MULTIPLE -> streamsOf(i)
            else -> emptyList()
        }
        if (uris.isEmpty()) return
        val app = applicationContext
        Engine.scope.launch {
            try {
                val kept = withContext(Dispatchers.IO) { uris.take(10).map { MediaFiles.keep(app, it) } }
                val video = kept.any { it.isVideo }
                showDraft(kept.filter { it.isVideo == video }.map { it.path }, text, video)
            } catch (e: Exception) {
                toast(app, "Could not read the shared file")
            }
        }
    }

    private fun showDraft(paths: List<String>, text: String, isVideo: Boolean) {
        Nav.stack.clear()
        Nav.tab = 2
        PostDraft.set(paths, text, isVideo)
    }

    @Suppress("DEPRECATION")
    private fun streamOf(i: Intent): Uri? =
        if (Build.VERSION.SDK_INT >= 33) {
            i.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
        } else {
            i.getParcelableExtra(Intent.EXTRA_STREAM) as? Uri
        }

    @Suppress("DEPRECATION")
    private fun streamsOf(i: Intent): List<Uri> =
        if (Build.VERSION.SDK_INT >= 33) {
            i.getParcelableArrayListExtra(Intent.EXTRA_STREAM, Uri::class.java) ?: emptyList()
        } else {
            i.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM) ?: emptyList()
        }
}

private class Tab(val label: String, val icon: ImageVector)

private val tabs = listOf(
    Tab("Home", Icons.Filled.Home),
    Tab("Pages", Icons.Filled.AccountBox),
    Tab("Post", Icons.Filled.AddCircle),
    Tab("Library", Icons.AutoMirrored.Filled.List),
    Tab("More", Icons.Filled.Menu),
)

@Composable
fun Root() {
    val ctx = LocalContext.current
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    var tab by Nav::tab
    val top = Nav.stack.lastOrNull()
    BackHandler(enabled = top != null) { Nav.pop() }
    BackHandler(enabled = top == null && tab != 0) { tab = 0 }

    if (top != null) {
        when (top) {
            Route.Connections -> ConnectionsScreen()
            Route.FacebookConnect -> FacebookConnectScreen()
            Route.ZernioConnect -> ZernioConnectScreen()
            Route.Settings -> SettingsScreen()
            Route.Queue -> QueueScreen()
            Route.Analytics -> AnalyticsScreen()
            Route.Ads -> AdsScreen()
            Route.Background -> BackgroundScreen()
            Route.Guides -> GuidesScreen()
            Route.PermanentLink -> PermanentLinkScreen()
            is Route.PageEdit -> PageEditScreen(top.id)
            is Route.Folder -> FolderScreen(top.id)
        }
        return
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(C.bg)
            .safeDrawingPadding(),
    ) {
        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth(),
        ) {
            when (tab) {
                0 -> HomeScreen(onTab = { tab = it })
                1 -> PagesScreen()
                2 -> PostScreen()
                3 -> LibraryScreen()
                else -> MoreScreen()
            }
        }
        NavigationBar(containerColor = C.card) {
            tabs.forEachIndexed { i, t ->
                NavigationBarItem(
                    selected = tab == i,
                    onClick = { tab = i },
                    icon = { Icon(t.icon, contentDescription = t.label) },
                    label = { Text(t.label) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = C.orange,
                        selectedTextColor = C.orange,
                        indicatorColor = C.card2,
                        unselectedIconColor = C.muted,
                        unselectedTextColor = C.muted,
                    ),
                )
            }
        }
    }
}
