package com.abuploader.app.ui

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mydownloader.app.Neon

/** Colors follow AB Downloader's theme (Settings → Theme), so the Pages part matches the app. */
object C {
    val bg: Color get() = Neon.Bg1
    val card: Color get() = Neon.Card
    val card2: Color get() = Neon.Card2
    val border: Color get() = Neon.Violet.copy(alpha = 0.35f)
    val text: Color get() = Neon.Text
    val muted: Color get() = Neon.Muted
    val orange: Color get() = Neon.Purple // main accent
    val amber: Color get() = Neon.Pink // second accent (links, icons)
    val green: Color get() = Neon.Green
    val red = Color(0xFFEF6B6B)
    val blue = Color(0xFF3B82F6)
    val gradient: Brush get() = Neon.Gradient
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = C.orange,
            onPrimary = Color.White,
            secondary = C.amber,
            background = C.bg,
            onBackground = C.text,
            surface = C.card,
            onSurface = C.text,
            surfaceVariant = C.card2,
            onSurfaceVariant = C.muted,
            surfaceContainer = C.card,
            surfaceContainerHigh = C.card2,
            outline = C.border,
            error = C.red,
        ),
        content = content,
    )
}

fun toast(ctx: Context, msg: String) {
    Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()
}

/** Splits text into items separated by an empty line. */
fun splitBlocks(text: String): List<String> =
    text.split(Regex("\\n\\s*\\n")).map { it.trim() }.filter { it.isNotEmpty() }

// ---------- layout helpers (inline so screens always redraw with fresh data) ----------

@Composable
inline fun AppCard(
    modifier: Modifier = Modifier,
    noinline onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    val base = modifier
        .fillMaxWidth()
        .padding(vertical = 6.dp)
        .clip(RoundedCornerShape(22.dp))
        .background(C.card)
        .border(1.dp, C.border, RoundedCornerShape(22.dp))
    Column(
        modifier = (if (onClick != null) base.clickable(onClick = onClick) else base).padding(18.dp),
        content = content,
    )
}

/** Full screen page with a back arrow, used for everything opened from a tab. */
@Composable
inline fun SubScreen(
    title: String,
    guide: String? = null,
    actions: @Composable RowScope.() -> Unit = {},
    fab: @Composable BoxScope.() -> Unit = {},
    content: @Composable ColumnScope.() -> Unit,
) {
    Box(
        Modifier
            .fillMaxSize()
            .background(C.bg)
            .safeDrawingPadding(),
    ) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(60.dp)
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = { Nav.pop() }) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = C.text)
                }
                Text(
                    title,
                    color = C.text,
                    fontSize = 21.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f),
                )
                actions()
                if (guide != null) GuideButton(guide)
            }
            Column(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(start = 20.dp, end = 20.dp, bottom = 100.dp),
            ) {
                content()
            }
        }
        Box(
            Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp),
        ) {
            fab()
        }
    }
}

// ---------- widgets ----------

@Composable
fun GuideButton(text: String) {
    var open by remember { mutableStateOf(false) }
    IconButton(onClick = { open = true }) {
        Icon(Icons.Filled.Info, contentDescription = "Guide", tint = C.amber)
    }
    if (open) {
        AlertDialog(
            onDismissRequest = { open = false },
            confirmButton = { TextButton(onClick = { open = false }) { Text("OK") } },
            title = { Text("Guide") },
            text = { Text(text, color = C.muted, lineHeight = 22.sp) },
            containerColor = C.card,
        )
    }
}

@Composable
fun ScreenTitle(title: String, hello: String? = null, guide: String? = null) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(top = 12.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            if (hello != null) Text(hello, color = C.muted, fontSize = 16.sp)
            Text(title, color = C.text, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold)
        }
        if (guide != null) GuideButton(guide)
    }
}

@Composable
fun GradientButton(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    enabled: Boolean = true,
) {
    Row(
        modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .height(56.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(if (enabled) C.gradient else Brush.linearGradient(listOf(C.card2, C.card2)))
            .clickable(enabled = enabled, onClick = onClick),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, tint = Color.White)
            Spacer(Modifier.width(8.dp))
        }
        Text(label, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun OutlineButton(label: String, onClick: () -> Unit, modifier: Modifier = Modifier, color: Color = C.text) {
    Box(
        modifier
            .padding(vertical = 6.dp)
            .height(50.dp)
            .clip(RoundedCornerShape(16.dp))
            .border(1.dp, C.border, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, color = color, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

@Composable
fun IconTile(icon: ImageVector, color: Color) {
    Box(
        Modifier
            .size(48.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(color.copy(alpha = 0.16f)),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, contentDescription = null, tint = color)
    }
}

@Composable
fun MenuRow(icon: ImageVector, color: Color, title: String, subtitle: String, onClick: () -> Unit) {
    AppCard(onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconTile(icon, color)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = C.text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text(subtitle, color = C.muted, fontSize = 14.sp)
            }
            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null, tint = C.muted)
        }
    }
}

/** Pill-style segmented switch. */
@Composable
fun Segmented(options: List<String>, index: Int, onChange: (Int) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(C.card)
            .border(1.dp, C.border, RoundedCornerShape(16.dp))
            .padding(4.dp),
    ) {
        options.forEachIndexed { i, o ->
            val sel = i == index
            Box(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (sel) C.gradient else Brush.linearGradient(listOf(C.card, C.card)))
                    .clickable { onChange(i) }
                    .padding(vertical = 11.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    o,
                    color = if (sel) Color.White else C.muted,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

/** Small selectable chip. */
@Composable
fun Chip(label: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier
            .padding(4.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(if (selected) C.orange else C.card)
            .border(1.dp, if (selected) C.orange else C.border, RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 9.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, color = if (selected) Color.White else C.text, fontSize = 14.sp, maxLines = 1)
    }
}

@Composable
fun Pill(text: String, color: Color) {
    Box(
        Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(color.copy(alpha = 0.16f))
            .padding(horizontal = 10.dp, vertical = 4.dp),
    ) {
        Text(text, color = color, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun SectionLabel(text: String, trailing: String? = null, onTrailing: (() -> Unit)? = null) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(top = 16.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(text, color = C.text, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
        if (trailing != null && onTrailing != null) {
            Text(
                trailing,
                color = C.amber,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier
                    .clickable(onClick = onTrailing)
                    .padding(6.dp),
            )
        }
    }
}

@Composable
fun EmptyState(
    icon: ImageVector,
    title: String,
    text: String,
    buttonLabel: String? = null,
    onButton: (() -> Unit)? = null,
) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            Modifier
                .size(72.dp)
                .clip(CircleShape)
                .background(C.card2),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, contentDescription = null, tint = C.amber, modifier = Modifier.size(34.dp))
        }
        Spacer(Modifier.height(12.dp))
        Text(title, color = C.text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text(text, color = C.muted, fontSize = 15.sp)
        if (buttonLabel != null && onButton != null) {
            Spacer(Modifier.height(10.dp))
            GradientButton(buttonLabel, onButton)
        }
    }
}

@Composable
fun Stepper(label: String, value: Int, onChange: (Int) -> Unit, min: Int = 0, max: Int = 48) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, color = C.text, fontSize = 16.sp, modifier = Modifier.weight(1f))
        StepBtn("−") { if (value > min) onChange(value - 1) }
        Text(
            "$value",
            color = C.text,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.width(48.dp),
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
        )
        StepBtn("+") { if (value < max) onChange(value + 1) }
    }
}

@Composable
private fun StepBtn(t: String, onClick: () -> Unit) {
    Box(
        Modifier
            .size(40.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(C.card2)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(t, color = C.amber, fontSize = 22.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun SwitchRow(title: String, checked: Boolean, onChange: (Boolean) -> Unit, subtitle: String? = null) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = C.text, fontSize = 16.sp)
            if (subtitle != null) Text(subtitle, color = C.muted, fontSize = 13.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = C.orange,
                uncheckedThumbColor = C.muted,
                uncheckedTrackColor = C.card2,
            ),
        )
    }
}

@Composable
fun Field(
    value: String,
    onChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    minLines: Int = 1,
    maxLines: Int = 1,
    secret: Boolean = false,
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        minLines = minLines,
        maxLines = maxLines,
        singleLine = maxLines == 1,
        visualTransformation = if (secret) {
            androidx.compose.ui.text.input.PasswordVisualTransformation()
        } else {
            androidx.compose.ui.text.input.VisualTransformation.None
        },
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        shape = RoundedCornerShape(16.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = C.orange,
            unfocusedBorderColor = C.border,
            focusedLabelColor = C.orange,
            unfocusedLabelColor = C.muted,
            focusedTextColor = C.text,
            unfocusedTextColor = C.text,
            cursorColor = C.orange,
            focusedContainerColor = C.card,
            unfocusedContainerColor = C.card,
        ),
    )
}

/** Dialog asking for one line of text. */
@Composable
fun InputDialog(
    title: String,
    label: String,
    initial: String = "",
    onDismiss: () -> Unit,
    onOk: (String) -> Unit,
) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = { onOk(text.trim()) }) { Text("OK") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
        title = { Text(title) },
        text = { Field(text, { text = it }, label) },
        containerColor = C.card,
    )
}

/** Yes / no dialog. */
@Composable
fun ConfirmDialog(title: String, text: String, yes: String, onDismiss: () -> Unit, onYes: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onYes) { Text(yes, color = C.red) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
        title = { Text(title) },
        text = { Text(text, color = C.muted) },
        containerColor = C.card,
    )
}
