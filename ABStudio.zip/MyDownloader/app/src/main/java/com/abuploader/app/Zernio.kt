package com.abuploader.app

import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class ZernioException(message: String) : Exception(message)

/** One Facebook Page reachable through a Zernio account. */
class ZernioPage(
    val accountId: String,
    val pageId: String?,
    val name: String,
    val followers: Int,
)

/** Result of reading one Zernio account: its Facebook Pages and how many channels it uses. */
class ZernioScan(val pages: List<ZernioPage>, val channelsUsed: Int)

/** Zernio REST API (Bearer API key). Blocking: call from a background thread. */
object Zernio {
    private const val BASE = "https://zernio.com/api/v1"

    private fun headers(key: String) = mapOf(
        "Authorization" to "Bearer $key",
        "Accept" to "application/json",
    )

    /** Returns JSONObject or JSONArray. Throws a readable error for bad replies. */
    private fun decode(r: Http.Resp): Any {
        if (r.code == 401 || r.code == 403) {
            throw ZernioException("Zernio refused the API key. Check that it is correct.")
        }
        val text = r.body.trim()
        val body: Any = try {
            when {
                text.isEmpty() -> JSONObject()
                text.startsWith("[") -> JSONArray(text)
                else -> JSONObject(text)
            }
        } catch (e: Exception) {
            throw ZernioException("Unexpected reply from Zernio (${r.code})")
        }
        if (!r.ok) {
            var msg = "Zernio error ${r.code}"
            if (body is JSONObject) {
                val eo = body.optJSONObject("error")
                msg = when {
                    eo != null -> eo.optString("message", msg)
                    body.str("error") != null -> body.optString("error")
                    body.str("message") != null -> body.optString("message")
                    else -> msg
                }
            }
            throw ZernioException(msg)
        }
        return body
    }

    private fun objects(body: Any, vararg keys: String): List<JSONObject> {
        val arr: JSONArray? = when (body) {
            is JSONArray -> body
            is JSONObject -> keys.firstNotNullOfOrNull { body.optJSONArray(it) }
            else -> null
        }
        val out = mutableListOf<JSONObject>()
        if (arr != null) {
            for (i in 0 until arr.length()) arr.optJSONObject(i)?.let { out.add(it) }
        }
        return out
    }

    /** Every Facebook Page the Zernio accounts of this key can post to, plus the channel count. */
    fun scan(key: String): ZernioScan {
        val accounts = objects(decode(Http.get("$BASE/accounts", headers(key))), "accounts", "data", "items")
        // Every connected account is one channel; disabled (enabled=false) ones are not billed.
        val used = accounts.count { a -> !(a.has("enabled") && !a.optBoolean("enabled", true)) }
        val out = mutableListOf<ZernioPage>()
        for (a in accounts) {
            if (a.optString("platform").lowercase() != "facebook") continue
            val accountId = a.str("_id") ?: a.str("id") ?: continue
            val fallback = a.str("displayName") ?: a.str("name") ?: a.str("username") ?: "Facebook Page"
            var added = 0
            try {
                val pj = decode(Http.get("$BASE/accounts/$accountId/facebook-page", headers(key)))
                for (p in objects(pj, "pages", "data")) {
                    val pageId = p.str("id") ?: continue
                    val followers = if (p.has("fan_count")) p.optInt("fan_count") else p.optInt("followers_count")
                    out.add(ZernioPage(accountId, pageId, p.str("name") ?: fallback, followers))
                    added++
                }
            } catch (_: Exception) {
                // fall back to the account's default Page below
            }
            if (added == 0) out.add(ZernioPage(accountId, null, fallback, 0))
        }
        return ZernioScan(out, used)
    }

    fun facebookPages(key: String): List<ZernioPage> = scan(key).pages

    /** The id of the account's default profile (every Zernio team has one). */
    fun defaultProfileId(key: String): String {
        val profiles = objects(decode(Http.get("$BASE/profiles", headers(key))), "profiles", "data", "items")
        val p = profiles.firstOrNull { it.optBoolean("isDefault", false) } ?: profiles.firstOrNull()
        return p?.str("_id") ?: p?.str("id") ?: throw ZernioException("This Zernio account has no profile")
    }

    /**
     * A link the Page owner opens to connect one Facebook Page into this Zernio account.
     * Zernio shows a branded welcome screen and its own Page picker. Valid for 30 minutes.
     */
    fun connectLink(key: String, profileId: String): String {
        val url = Http.withQuery(
            "$BASE/connect/facebook",
            mapOf(
                "profileId" to profileId,
                "welcome" to "true",
                "brandName" to "AB Uploader",
                "primaryColor" to "#FF7A00",
                "scopes" to "posting,comments,analytics",
            ),
        )
        val j = decode(Http.get(url, headers(key)))
        if (j is JSONObject) {
            j.str("authUrl")?.let { return it }
            if (j.optJSONObject("account") != null) {
                throw ZernioException("Zernio re-enabled an existing Page instead. Tap Refresh.")
            }
        }
        throw ZernioException("Zernio did not return a connect link")
    }

    /** Uploads one file to Zernio storage and returns its public url. */
    fun upload(key: String, path: String): String {
        val f = File(path)
        val ext = path.substringAfterLast('.', "").lowercase()
        val type = mimeOf(path)
        if (type == null || type == "video/3gpp" || type == "video/x-matroska") {
            throw ZernioException("Zernio does not accept .$ext files. Use MP4, MOV, JPG or PNG.")
        }
        val req = JSONObject()
            .put("filename", f.name)
            .put("contentType", type)
            .put("size", f.length())
        val pre = decode(Http.sendJson("$BASE/media/presign", "POST", req.toString(), headers(key), 30_000))
        if (pre !is JSONObject) throw ZernioException("Zernio did not give an upload address")
        val uploadUrl = pre.str("uploadUrl") ?: throw ZernioException("Zernio did not give an upload address")
        val publicUrl = pre.str("publicUrl") ?: throw ZernioException("Zernio did not give an upload address")

        val put = Http.sendFile(uploadUrl, "PUT", f, mapOf("Content-Type" to type))
        if (!put.ok) throw ZernioException("Upload to Zernio failed (${put.code})")
        return publicUrl
    }

    fun publish(page: PageAccount, post: ScheduledPost) {
        val key = page.zernioKey ?: throw ZernioException("Page is not connected to Zernio")
        val accountId = page.zernioAccountId ?: throw ZernioException("Page is not connected to Zernio")
        if (post.media.isEmpty()) throw ZernioException("No media selected")
        for (m in post.media) {
            if (!File(m).exists()) throw ZernioException("Media file not found on this phone")
        }
        val files = if (post.type == PostType.PHOTOS) post.media else listOf(post.media.first())
        val items = JSONArray()
        for (p in files) {
            val url = upload(key, p)
            items.put(JSONObject().put("type", if (post.type.needsVideo) "video" else "image").put("url", url))
        }

        val psd = JSONObject()
        page.fbId?.let { if (it.isNotEmpty()) psd.put("pageId", it) }
        when (post.type) {
            PostType.REEL -> psd.put("contentType", "reel")
            PostType.IMG_STORY, PostType.VIDEO_STORY -> psd.put("contentType", "story")
            else -> {}
        }
        val comment = post.firstComment
        if (!post.type.isStory && !comment.isNullOrBlank()) psd.put("firstComment", comment)

        val platform = JSONObject().put("platform", "facebook").put("accountId", accountId)
        if (psd.length() > 0) platform.put("platformSpecificData", psd)
        val body = JSONObject()
            .put("content", if (post.type.isStory) "" else post.caption)
            .put("mediaItems", items)
            .put("platforms", JSONArray().put(platform))
            .put("publishNow", true)

        val j = decode(Http.sendJson("$BASE/posts", "POST", body.toString(), headers(key), 5 * 60_000))
        val p = (j as? JSONObject)?.optJSONObject("post") ?: return
        val first = p.optJSONArray("platforms")?.optJSONObject(0)
        if (first != null && first.optString("status") == "failed") {
            throw ZernioException(
                first.str("errorMessage") ?: first.str("error") ?: "Zernio could not publish the post",
            )
        }
        if (p.optString("status") == "failed") throw ZernioException("Zernio could not publish the post")
    }
}
