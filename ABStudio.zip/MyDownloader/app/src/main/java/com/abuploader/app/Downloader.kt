package com.abuploader.app

import android.content.Context
import com.mydownloader.app.CreatorStore
import com.mydownloader.app.Posted
import com.mydownloader.app.Titles
import com.mydownloader.app.UploadQueue
import java.io.File

/**
 * Bridge between the Pages part (AB Uploader) and AB Downloader, which now live in one app.
 * - A Library folder can follow a Downloader creator folder ("abd:" + folder path).
 * - Autopilot picks the next video the way AB Downloader's upload queue does
 *   (unfinished series first, Part 1, 2, 3..., the [Reels] version when there is one).
 * - Captions come from AB Downloader (the original TikTok/IG caption, "Part N" on top).
 * - After a post goes out the video gets the ✅ posted tick in AB Downloader.
 */
object Downloader {
    const val PREFIX = "abd:"
    private val videoExt = setOf("mp4", "mkv", "webm", "mov", "m4v", "3gp")
    private val imageExt = setOf("jpg", "jpeg", "png", "webp")
    private var prefsLoaded = false

    class CreatorFolder(val name: String, val dir: File)

    /** AB Downloader's creators and their folders. */
    fun creators(ctx: Context): List<CreatorFolder> = try {
        CreatorStore.load(ctx).map {
            CreatorFolder(it.name, com.mydownloader.app.Engine.publicFolder(it.base, it.folder))
        }
    } catch (e: Exception) {
        emptyList()
    }

    fun isLink(uri: String?): Boolean = uri?.startsWith(PREFIX) == true
    fun dirOf(uri: String): File = File(uri.removePrefix(PREFIX))

    /** A real file outside the app's own copies (AB Downloader keeps its videos in Download/...). */
    fun isDownloaderFile(path: String): Boolean = path.startsWith("/") && !path.contains("/files/media/")

    /** Videos and images in a creator folder (parts and [Reels] versions too). Blocking. */
    fun list(dir: File): List<MediaFile> {
        if (!dir.exists()) return emptyList()
        return dir.walkTopDown().maxDepth(3)
            .filter { it.isFile && it.length() > 0 && it.extension.lowercase() in videoExt + imageExt }
            .map { MediaFile(it.absolutePath, it.extension.lowercase() in videoExt, it.name) }
            .sortedBy { File(it.path).lastModified() }
            .toList()
    }

    /** The next file to post from a creator folder, skipping posted and already planned ones. */
    fun next(ctx: Context, files: List<MediaFile>, planned: Set<String>): MediaFile? = try {
        val existing = files.map { File(it.path) }.filter { it.exists() }
        val (f, _) = UploadQueue.next(existing, Posted.all(ctx) + planned)
        if (f == null) null else files.firstOrNull { it.path == f.absolutePath }
    } catch (e: Exception) {
        null
    }

    /** The caption AB Downloader would use when sharing this video, or null. */
    fun caption(ctx: Context, path: String): String? {
        if (!isDownloaderFile(path)) return null
        return try {
            if (!prefsLoaded) {
                Titles.loadPrefs(ctx)
                prefsLoaded = true
            }
            Titles.get(ctx, File(path)).trim().ifEmpty { null }
        } catch (e: Exception) {
            null
        }
    }

    fun markPosted(ctx: Context, path: String) {
        if (!isDownloaderFile(path)) return
        try {
            Posted.mark(ctx, File(path))
        } catch (_: Exception) {
        }
    }
}
