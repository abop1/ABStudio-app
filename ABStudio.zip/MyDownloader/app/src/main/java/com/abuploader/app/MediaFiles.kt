package com.abuploader.app

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import java.io.File

/** Copies picked files into the app's own storage so they stay available. */
object MediaFiles {
    private fun dir(ctx: Context): File = File(ctx.filesDir, "media").apply { mkdirs() }

    /** Blocking: call from a background thread. */
    fun keep(ctx: Context, uri: Uri): MediaFile {
        val cr = ctx.contentResolver
        val mime = cr.getType(uri) ?: ""
        var name = "file"
        try {
            cr.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (i >= 0) c.getString(i)?.let { name = it }
                }
            }
        } catch (_: Exception) {
        }
        name = name.replace(Regex("[^A-Za-z0-9._-]"), "_")
        if (!name.contains('.')) {
            val ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(mime)
            if (ext != null) name = "$name.$ext"
        }
        val dest = File(dir(ctx), "${System.currentTimeMillis()}_$name")
        val input = cr.openInputStream(uri) ?: throw Exception("Could not read the file")
        input.use { inp -> dest.outputStream().use { inp.copyTo(it, 64 * 1024) } }
        return MediaFile(dest.absolutePath, mime.startsWith("video") || isVideoPath(name))
    }

    fun delete(path: String) {
        try {
            // Only AB Uploader's own copies; never AB Downloader's videos or gallery files.
            if (path.contains("/files/media/")) File(path).delete()
        } catch (_: Exception) {
        }
    }

    fun isVideoPath(path: String): Boolean =
        path.substringAfterLast('.', "").lowercase() in
            setOf("mp4", "mov", "mkv", "webm", "3gp", "avi", "m4v", "mpeg", "mpg")

    private val mediaExt = setOf("jpg", "jpeg", "png", "gif", "webp", "mp4", "mov", "m4v", "webm", "3gp", "mkv", "avi", "mpeg", "mpg")

    /** Readable name of a linked phone folder, e.g. "DCIM/asmr". */
    fun treeName(treeUri: Uri): String {
        val id = try {
            DocumentsContract.getTreeDocumentId(treeUri)
        } catch (_: Exception) {
            return "Phone folder"
        }
        return id.substringAfter(':').ifEmpty { "Phone storage" }
    }

    /**
     * Images and videos directly inside a linked phone folder, sorted by name.
     * Blocking: call from a background thread. Throws if the folder can no longer be read.
     */
    fun listTree(ctx: Context, treeUri: Uri): List<MediaFile> {
        val cr = ctx.contentResolver
        val parentId = DocumentsContract.getTreeDocumentId(treeUri)
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentId)
        val cols = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
        )
        val out = mutableListOf<MediaFile>()
        val c = cr.query(children, cols, null, null, null) ?: throw Exception("Phone folder not readable")
        c.use {
            while (it.moveToNext()) {
                val docId = it.getString(0) ?: continue
                val name = it.getString(1) ?: continue
                val mime = it.getString(2) ?: ""
                val ext = name.substringAfterLast('.', "").lowercase()
                val video = mime.startsWith("video") || ext in setOf("mp4", "mov", "m4v", "webm", "3gp", "mkv", "avi", "mpeg", "mpg")
                val image = mime.startsWith("image") || ext in setOf("jpg", "jpeg", "png", "gif", "webp")
                if (!video && !image) continue
                if (ext !in mediaExt && !mime.startsWith("image") && !mime.startsWith("video")) continue
                val uri = DocumentsContract.buildDocumentUriUsingTree(treeUri, docId)
                out.add(MediaFile(uri.toString(), video, name))
            }
        }
        return out.sortedBy { it.name.lowercase() }
    }

    /**
     * Uploads need a real file. A linked (content://) file is copied to the cache first;
     * the copy is added to [temps] so the caller can delete it afterwards. Blocking.
     */
    fun localCopy(ctx: Context, path: String, title: String?, temps: MutableList<File>): String {
        if (!path.startsWith("content://")) return path
        val uri = Uri.parse(path)
        val cr = ctx.contentResolver
        var name = (title ?: "file").replace(Regex("[^A-Za-z0-9._-]"), "_")
        if (!name.contains('.')) {
            val ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(cr.getType(uri) ?: "")
            if (ext != null) name = "$name.$ext"
        }
        val dest = File(ctx.cacheDir, "upload_${System.currentTimeMillis()}_$name")
        val input = cr.openInputStream(uri) ?: throw Exception("The file in the linked phone folder is gone")
        input.use { inp -> dest.outputStream().use { inp.copyTo(it, 64 * 1024) } }
        temps.add(dest)
        return dest.absolutePath
    }
}
